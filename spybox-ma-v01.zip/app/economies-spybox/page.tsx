import type { Metadata } from "next"
import { PageHeader } from "@/components/spybox/page-header"
import { CoconLinks } from "@/components/spybox/cocon-links"
import { ArticleJsonLd } from "@/components/spybox/article-json-ld"
import { ArrowRight } from "lucide-react"

const SPYBOX_LINK = "https://spybox.io/?via=sign-ma"

export const metadata: Metadata = {
  title: "Économies Spybox -- Combien économisez-vous chaque année ?",
  description: "Analysez les économies réalisées avec Spybox : jusqu'à 8 000 €/an. Mensuel 34,99 €/mois ou annuel 249,99 €/an (soit 20,83 €/mois).",
  alternates: { canonical: "/economies-spybox" },
}

const examples = [
  { profil: "Dropshipper débutant", outils: "Minea + AdSpy + ChatGPT", cout: 266, ecoMensuel: "2 771 €/an", ecoAnnuel: "2 940 €/an" },
  { profil: "Consultant SEO", outils: "Semrush + Ahrefs + Mangools", cout: 278, ecoMensuel: "2 916 €/an", ecoAnnuel: "3 086 €/an" },
  { profil: "Agence digitale", outils: "Semrush + Minea + AdSpy + Midjourney + ChatGPT + Runway", cout: 562, ecoMensuel: "6 324 €/an", ecoAnnuel: "6 494 €/an" },
  { profil: "E-commerçant avancé", outils: "Stack complète 8+ outils", cout: 750, ecoMensuel: "8 580 €/an", ecoAnnuel: "8 750 €/an" },
]

export default function EconomiesSpybox() {
  return (
    <>
      <ArticleJsonLd title="Économies Spybox" description="Économies avec Spybox (mensuel et annuel) vs abonnements individuels." slug="economies-spybox" datePublished="2025-03-10" dateModified="2025-06-01" />
      <article>
        <PageHeader badge="Budget" title="Économies Spybox : jusqu'à 8 750 € par an sur vos outils" description="Comparez le coût des abonnements individuels avec Spybox : 34,99 €/mois ou 349,99 €/an (soit 20,83 €/mois)." />

        <section className="border-t border-border py-16">
          <div className="mx-auto max-w-4xl px-4 lg:px-8 space-y-8 text-base leading-relaxed text-muted-foreground">
            <h2 className="text-2xl font-bold text-foreground">Exemples d'économies par profil</h2>
            <div className="grid gap-4 sm:grid-cols-2">
              {examples.map((e) => (
                <div key={e.profil} className="rounded-xl border border-border bg-card p-5">
                  <h3 className="font-bold text-foreground">{e.profil}</h3>
                  <p className="mt-1 text-sm">{e.outils}</p>
                  <div className="mt-3 space-y-1 text-sm">
                    <div className="flex justify-between">
                      <span>Coût seul : <span className="line-through">{e.cout} €/mois</span></span>
                    </div>
                    <div className="flex justify-between">
                      <span>Mensuel Spybox</span>
                      <span className="font-bold text-primary">{e.ecoMensuel}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Annuel Spybox</span>
                      <span className="font-bold text-primary">{e.ecoAnnuel}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <h2 className="text-2xl font-bold text-foreground pt-4">Mensuel vs Annuel : le comparatif</h2>
            <p>En <strong className="text-foreground">mensuel</strong>, Spybox coûte 34,99 €/mois soit 419,88 €/an. En <strong className="text-foreground">annuel</strong>, le tarif passe à 249,99 €/an (20,83 €/mois), soit <strong className="text-primary">169,89 € d'économie supplémentaire</strong> par rapport au mensuel. Dès que votre stack dépasse 21 €/mois, l'annuel devient plus avantageux.</p>

            <div className="pt-4 text-center">
              <a href={SPYBOX_LINK} target="_blank" rel="noopener noreferrer" className="inline-flex h-12 items-center gap-2 rounded-xl bg-primary px-8 font-bold text-primary-foreground transition-all hover:bg-accent hover:shadow-lg hover:shadow-primary/25">
                Économiser avec Spybox -- Code GET25
                <ArrowRight className="h-4 w-4" aria-hidden="true" />
              </a>
            </div>
          </div>
        </section>
        <CoconLinks current="/economies-spybox" links={[
          { href: "/prix-spybox", label: "Prix Spybox 2025" },
          { href: "/code-promo-get25", label: "Code promo GET25" },
          { href: "/simulateur-economies-spybox", label: "Simulateur d'économies" },
          { href: "/credits-recharges-spybox", label: "Crédits et recharges" },
          { href: "/spybox-vs-semrush", label: "Spybox vs Semrush" },
        ]} />
      </article>
    </>
  )
}
