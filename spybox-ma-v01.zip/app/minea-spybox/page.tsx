import type { Metadata } from "next"
import { PageHeader } from "@/components/spybox/page-header"
import { CoconLinks } from "@/components/spybox/cocon-links"
import { ArticleJsonLd } from "@/components/spybox/article-json-ld"

export const metadata: Metadata = {
  title: "Minea dans Spybox : Accès Complet à l'Outil de Product Research (2025)",
  description: "Accédez à Minea via Spybox : recherche de produits gagnants, espionnage de boutiques, analyse de tendances e-commerce. Inclus dans l'abonnement 34,99 €/mois.",
  alternates: { canonical: "/minea-spybox" },
}

export default function Page() {
  return (
    <>
      <ArticleJsonLd
        title="Minea dans Spybox : Accès Complet à l'Outil de Product Research"
        description="Accédez à Minea via Spybox pour la recherche de produits gagnants e-commerce."
        slug="minea-spybox"
        faq={[
          { q: "Est-ce que Minea dans Spybox est la version complète ?", a: "Oui, Spybox donne accès à Minea avec ses fonctionnalités premium : recherche de produits, espionnage de boutiques et analyse des tendances e-commerce." },
          { q: "Combien coûte Minea seul vs dans Spybox ?", a: "Minea coûte 149 €/mois en abonnement direct. Dans Spybox, il est inclus avec 89 autres outils pour 34,99 €/mois." },
        ]}
      />
      <PageHeader
        h1="Minea dans Spybox : la recherche de produits gagnants à portée de clic"
        breadcrumb={[
          { label: "Accueil", href: "/" },
          { label: "Product Research" },
          { label: "Minea" },
        ]}
        subtitle="Minea est l'outil de référence pour identifier les produits e-commerce à fort potentiel. Découvrez comment y accéder via Spybox."
      />
      <article className="mx-auto max-w-4xl px-4 py-12 lg:px-8 lg:py-16">
        <div className="space-y-6 text-base leading-relaxed text-muted-foreground">
          <h2 className="text-2xl font-bold text-foreground">Minea : l'outil incontournable du product research</h2>
          <p>
            Minea est une plateforme de recherche de produits e-commerce utilisée par des dizaines de milliers de dropshippers et e-commerçants. Elle scrute les publicités Facebook, TikTok, Pinterest et Instagram pour identifier les produits qui génèrent le plus d'engagement et de ventes. Son algorithme analyse les tendances en temps réel pour vous donner une longueur d'avance sur la concurrence.
          </p>

          <h2 className="text-2xl font-bold text-foreground">Ce que Minea permet dans Spybox</h2>
          <p>
            Via Spybox, vous accédez aux fonctionnalités clés de Minea : la recherche de produits par catégorie, pays et plateforme publicitaire, l'analyse des boutiques concurrentes avec leur catalogue et leurs best-sellers, le suivi des tendances produits sur 30, 60 et 90 jours, et l'export de données pour alimenter vos études de marché.
          </p>

          <h2 className="text-2xl font-bold text-foreground">Minea à 149 €/mois vs Spybox à 34,99 €/mois</h2>
          <p>
            L'abonnement Minea Premium coûte 149 €/mois en direct. En passant par Spybox, vous accédez à Minea plus 89 autres outils pour 34,99 €/mois avec le code <code className="rounded bg-primary/15 px-1.5 py-0.5 text-sm font-bold text-primary">GET25</code>. L'économie est considérable : vous payez l'équivalent de 23 % du prix de Minea seul, tout en bénéficiant de l'ensemble de la stack Spybox.
          </p>

          <h2 className="text-2xl font-bold text-foreground">Cas d'usage concret</h2>
          <p>
            Un dropshipper type lance sa session matinale sur Minea pour scanner les nouvelles publicités virales. Il identifie 3 produits potentiels, vérifie leur saturation de marché via ShopHunter (également inclus dans Spybox), puis utilise AdSpy pour analyser les créatives publicitaires des concurrents. Enfin, il génère ses propres visuels avec Midjourney. Tout cela depuis un seul abonnement Spybox.
          </p>

          <h2 className="text-2xl font-bold text-foreground">Comment accéder à Minea via Spybox</h2>
          <p>
            Après connexion au dashboard Spybox, rendez-vous dans la catégorie "Product Research" et cliquez sur Minea. Une session est ouverte automatiquement avec un accès complet. Les crédits SBC sont débités en fonction de votre utilisation.
          </p>
        </div>

        <CoconLinks
          title="Explorer le product research"
          links={[
            { label: "ShopHunter dans Spybox", href: "/shophunter-spybox" },
            { label: "Trouver des produits viraux", href: "/produits-viraux-spybox" },
            { label: "Analyse de marché e-commerce", href: "/analyse-marche-spybox" },
            { label: "Spybox pour le dropshipping", href: "/spybox-dropshipping" },
            { label: "Spybox vs Minea seul", href: "/spybox-vs-minea" },
            { label: "AdSpy dans Spybox", href: "/adspy-ppads-spybox" },
          ]}
        />
      </article>
    </>
  )
}
