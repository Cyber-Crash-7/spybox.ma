import { Hero } from "@/components/spybox/hero"
import { ToolsGrid } from "@/components/spybox/tools-grid"
import { Benefits } from "@/components/spybox/benefits"
import { PricingCta } from "@/components/spybox/pricing-cta"
import { FaqHome } from "@/components/spybox/faq-home"
import { HomeJsonLd } from "@/components/spybox/json-ld"
import { CoconLinks } from "@/components/spybox/cocon-links"
import Link from "next/link"
import { ArrowRight } from "lucide-react"

const SPYBOX_LINK = "https://spybox.io/?via=sign-ma"

export const metadata = {
  alternates: { canonical: "/" },
}

export default function Home() {
  return (
    <>
      <HomeJsonLd />
      <main>
        <Hero />
        <ToolsGrid />

        {/* Contenu expert SEO - Section 1 */}
        <section className="border-t border-border py-16 lg:py-20">
          <div className="mx-auto max-w-4xl px-4 lg:px-8">
            <h2 className="mb-8 text-2xl font-bold tracking-tight text-foreground md:text-3xl text-balance">
              La plateforme qui réinvente l'accès aux outils professionnels
            </h2>
            <div className="space-y-5 text-base leading-relaxed text-muted-foreground">
              <p>
                Dans l'écosystème e-commerce et marketing digital, les professionnels jonglent quotidiennement entre une multitude d'outils spécialisés. Recherche de produits gagnants avec Minea, espionnage publicitaire avec AdSpy, analyse SEO via Semrush ou Ahrefs, génération de contenu avec ChatGPT… Chaque outil représente un abonnement mensuel conséquent. Le coût cumulé dépasse facilement 8&nbsp;000&nbsp;€ par an pour une stack complète.
              </p>
              <p>
                Spybox a été conçu pour résoudre ce problème fondamental. La plateforme mutualise l'accès à plus de 90 outils premium via un système unique de crédits SBC (Spybox Credits). Chaque abonné reçoit 100&nbsp;000 crédits mensuels, suffisants pour un usage professionnel intensif quotidien. L'approche est simple : au lieu de payer chaque outil séparément, vous accédez à l'ensemble depuis un dashboard centralisé pour 34,99&nbsp;€/mois ou 249,99&nbsp;€/an (~5 mois offerts).
              </p>
              <p>
                Le modèle économique de Spybox repose sur la mutualisation intelligente des licences. En regroupant des milliers d'utilisateurs, la plateforme négocie des accès en volume auprès des éditeurs d'outils, répercutant l'économie directement sur le prix de l'abonnement. Le résultat : un ROI immédiat dès le premier mois pour chaque utilisateur.
              </p>
            </div>
          </div>
        </section>

        <Benefits />

        {/* Contenu expert SEO - Section 2 */}
        <section className="border-t border-border py-16 lg:py-20">
          <div className="mx-auto max-w-4xl px-4 lg:px-8">
            <h2 className="mb-8 text-2xl font-bold tracking-tight text-foreground md:text-3xl text-balance">
              Quatre catégories d'outils pour dominer votre marché
            </h2>
            <div className="space-y-5 text-base leading-relaxed text-muted-foreground">
              <p>
                La force de Spybox réside dans l'étendue de sa couverture fonctionnelle. Les outils de{" "}
                <strong className="text-foreground">Product Research</strong> (Minea, ShopHunter, Ecomhunt) vous permettent d'identifier les produits gagnants avant vos concurrents. Les modules{" "}
                <strong className="text-foreground">Ad Spy</strong> (AdSpy, PPAds, BigSpy) décortiquent les stratégies publicitaires sur Facebook, TikTok, Instagram et Pinterest.
              </p>
              <p>
                Côté référencement naturel, les outils{" "}
                <strong className="text-foreground">SEO</strong> intégrés (RankerFox, Semrush, Ahrefs, Mangools) couvrent l'analyse de mots-clés, l'audit technique, le suivi de positions et la stratégie de netlinking. Enfin, le pôle{" "}
                <strong className="text-foreground">Intelligence Artificielle</strong> (ChatGPT, Midjourney, Claude, Runway, ElevenLabs) accélère la production de contenus texte, image, vidéo et audio.
              </p>
              <p>
                Cette combinaison fait de Spybox une solution complète pour les dropshippers, les agences digitales, les consultants SEO et les e-commerçants qui souhaitent centraliser leur stack sans exploser leur budget opérationnel.
              </p>
            </div>

            {/* Maillage interne cocon vers clusters */}
            <CoconLinks
              links={[
                { label: "Qu'est-ce que Spybox ?", href: "/quest-ce-que-spybox" },
                { label: "Fonctionnement détaillé", href: "/fonctionnement-spybox" },
                { label: "Minea dans Spybox", href: "/minea-spybox" },
                { label: "RankerFox SEO", href: "/rankerfox-spybox" },
                { label: "Spybox pour le Dropshipping", href: "/spybox-dropshipping" },
                { label: "AdSpy & PPAds dans Spybox", href: "/adspy-ppads-spybox" },
                { label: "Outils IA Spybox", href: "/spybox-ia-images" },
                { label: "Prix Spybox 2026", href: "/prix-spybox" },
              ]}
            />
          </div>
        </section>

        <PricingCta />
        <FaqHome />

        {/* CTA final */}
        <section className="border-t border-border bg-primary/5 py-16 text-center">
          <div className="mx-auto max-w-2xl px-4">
            <h2 className="text-2xl font-bold text-foreground md:text-3xl text-balance">
              Prêt à accéder à 90+ outils premium ?
            </h2>
            <p className="mt-4 text-muted-foreground">
              Rejoignez 12&nbsp;000+ professionnels qui utilisent Spybox au quotidien. Appliquez le code{" "}
              <code className="rounded bg-primary/15 px-1.5 py-0.5 text-sm font-bold text-primary">GET25</code>{" "}
              lors de votre inscription.
            </p>
            <a
              href={SPYBOX_LINK}
              target="_blank"
              rel="noopener noreferrer"
              className="group mt-8 inline-flex h-12 items-center gap-2 rounded-xl bg-primary px-8 text-base font-bold text-primary-foreground transition-all hover:bg-accent hover:shadow-lg hover:shadow-primary/25"
            >
              Accéder à Spybox maintenant
              <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" aria-hidden="true" />
            </a>
          </div>
        </section>
      </main>
    </>
  )
}
