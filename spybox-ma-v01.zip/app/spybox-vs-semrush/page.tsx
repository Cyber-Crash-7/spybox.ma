import type { Metadata } from "next"
import { PageHeader } from "@/components/spybox/page-header"
import { CoconLinks } from "@/components/spybox/cocon-links"
import { ArticleJsonLd } from "@/components/spybox/article-json-ld"
import { ArrowRight, Check, X } from "lucide-react"

const SPYBOX_LINK = "https://spybox.io/?via=sign-ma"

export const metadata: Metadata = {
  title: "Spybox vs Semrush -- Comparaison prix, outils et fonctionnalit\u00e9s 2025",
  description: "Spybox vs Semrush : comparaison compl\u00e8te. 34,99 \u20ac/mois pour 90+ outils contre 129,95 \u20ac/mois pour le SEO seul. D\u00e9couvrez le meilleur choix.",
  alternates: { canonical: "/spybox-vs-semrush" },
}

const rows = [
  { f: "Audit SEO technique", s: true, sem: true },
  { f: "Keyword Research", s: true, sem: true },
  { f: "Suivi de positions", s: true, sem: true },
  { f: "Analyse de backlinks", s: true, sem: true },
  { f: "Analyse concurrentielle ads", s: true, sem: true },
  { f: "Espionnage publicitaire (AdSpy)", s: true, sem: false },
  { f: "Product Research (Minea)", s: true, sem: false },
  { f: "Outils IA g\u00e9n\u00e9ratifs", s: true, sem: false },
  { f: "90+ outils int\u00e9gr\u00e9s", s: true, sem: false },
  { f: "Prix mensuel", s: "34,99 \u20ac", sem: "129,95 \u20ac" },
]

export default function SpyboxVsSemrush() {
  return (
    <>
      <ArticleJsonLd
        title="Spybox vs Semrush -- Comparaison 2025"
        description="Comparaison d\u00e9taill\u00e9e Spybox vs Semrush : prix, outils, fonctionnalit\u00e9s."
        slug="spybox-vs-semrush"
        datePublished="2025-02-10"
        dateModified="2025-06-01"
      />
      <article>
        <PageHeader
          badge="Comparaison"
          title="Spybox vs Semrush : quelle plateforme choisir en 2025 ?"
          description="Semrush est un g\u00e9ant du SEO, mais Spybox propose 90+ outils pour un quart du prix. Voici le comparatif objectif."
        />
        <section className="border-t border-border py-16">
          <div className="mx-auto max-w-4xl px-4 lg:px-8 space-y-8 text-base leading-relaxed text-muted-foreground">
            <div className="overflow-x-auto rounded-xl border border-border">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border bg-secondary/50">
                    <th className="px-4 py-3 text-left font-semibold text-foreground">Fonctionnalit\u00e9</th>
                    <th className="px-4 py-3 text-center font-semibold text-primary">Spybox</th>
                    <th className="px-4 py-3 text-center font-semibold text-foreground">Semrush</th>
                  </tr>
                </thead>
                <tbody>
                  {rows.map((r) => (
                    <tr key={r.f} className="border-b border-border last:border-0">
                      <td className="px-4 py-3 text-foreground">{r.f}</td>
                      <td className="px-4 py-3 text-center">
                        {typeof r.s === "boolean" ? (r.s ? <Check className="mx-auto h-5 w-5 text-primary" /> : <X className="mx-auto h-5 w-5 text-destructive" />) : <span className="font-bold text-primary">{r.s}</span>}
                      </td>
                      <td className="px-4 py-3 text-center">
                        {typeof r.sem === "boolean" ? (r.sem ? <Check className="mx-auto h-5 w-5 text-primary" /> : <X className="mx-auto h-5 w-5 text-destructive" />) : <span className="font-semibold text-foreground">{r.sem}</span>}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <h2 className="text-2xl font-bold text-foreground">L'analyse</h2>
            <p>
              Semrush reste une r\u00e9f\u00e9rence ind\u00e9niable en SEO pur, avec une base de donn\u00e9es de mots-cl\u00e9s massive et des fonctionnalit\u00e9s avanc\u00e9es de content marketing. Cependant, son plan Pro \u00e0 129,95 \u20ac/mois ne couvre que le SEO et le SEA. Pour un professionnel du e-commerce qui a aussi besoin de product research et d'espionnage publicitaire, il faut ajouter Minea (97 \u20ac/mois) et AdSpy (149 $/mois).
            </p>
            <p>
              Spybox centralise tout dans un seul abonnement \u00e0 34,99 \u20ac/mois. RankerFox offre les fonctionnalit\u00e9s SEO essentielles (audit, keywords, positions, backlinks), tandis que les 90+ autres outils couvrent le product research, l'ad spy et la cr\u00e9ation IA. L'\u00e9conomie annuelle d\u00e9passe 7 000 \u20ac pour une stack compl\u00e8te.
            </p>

            <div className="pt-6 text-center">
              <a href={SPYBOX_LINK} target="_blank" rel="noopener noreferrer" className="inline-flex h-12 items-center gap-2 rounded-xl bg-primary px-8 font-bold text-primary-foreground transition-all hover:bg-accent hover:shadow-lg hover:shadow-primary/25">
                Choisir Spybox -- Code GET25
                <ArrowRight className="h-4 w-4" aria-hidden="true" />
              </a>
            </div>
          </div>
        </section>
        <CoconLinks current="/spybox-vs-semrush" links={[
          { href: "/spybox-vs-ahrefs", label: "Spybox vs Ahrefs" },
          { href: "/spybox-vs-group-buy", label: "Spybox vs Group Buy" },
          { href: "/meilleurs-outils-ecommerce", label: "Meilleurs outils e-commerce" },
          { href: "/prix-spybox", label: "Prix Spybox" },
          { href: "/simulateur-economies-spybox", label: "Simulateur d'\u00e9conomies" },
        ]} />
      </article>
    </>
  )
}
