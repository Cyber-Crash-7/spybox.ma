import type { Metadata } from "next"
import { PageHeader } from "@/components/spybox/page-header"
import { CoconLinks } from "@/components/spybox/cocon-links"
import { ArticleJsonLd } from "@/components/spybox/article-json-ld"
import { ArrowRight } from "lucide-react"

const SPYBOX_LINK = "https://spybox.io/?via=sign-ma"

export const metadata: Metadata = {
  title: "FAQ Spybox -- R\u00e9ponses aux questions fr\u00e9quentes",
  description: "Toutes les r\u00e9ponses aux questions fr\u00e9quentes sur Spybox : inscription, cr\u00e9dits SBC, outils inclus, r\u00e9siliation, support. Guide complet.",
  alternates: { canonical: "/faq-spybox" },
}

const faqs = [
  { q: "Qu'est-ce que Spybox exactement ?", a: "Spybox est une plateforme qui mutualise l'acc\u00e8s \u00e0 90+ outils premium (e-commerce, SEO, IA, Ad Spy) via un abonnement unique \u00e0 34,99 \u20ac/mois. Au lieu de payer chaque outil s\u00e9par\u00e9ment, vous acc\u00e9dez \u00e0 l'ensemble depuis un dashboard centralis\u00e9." },
  { q: "Combien co\u00fbte Spybox ?", a: "L'abonnement co\u00fbte 34,99 \u20ac/mois sans engagement. Vous pouvez r\u00e9silier \u00e0 tout moment. Appliquez le code promo GET25 pour b\u00e9n\u00e9ficier d'une r\u00e9duction suppl\u00e9mentaire." },
  { q: "Comment fonctionnent les cr\u00e9dits SBC ?", a: "Chaque outil consomme un certain nombre de cr\u00e9dits SBC par utilisation. Vous recevez 100 000 cr\u00e9dits par mois, suffisants pour un usage professionnel intensif quotidien. Des recharges sont disponibles si n\u00e9cessaire." },
  { q: "Quels outils sont inclus ?", a: "Plus de 90 outils : Minea, ShopHunter (product research), AdSpy, PPAds, BigSpy (ad spy), RankerFox, Semrush, Ahrefs (SEO), ChatGPT, Midjourney, Claude, Runway (IA), et bien d'autres." },
  { q: "Est-ce l\u00e9gal ?", a: "Oui. Contrairement aux group buy qui partagent ill\u00e9galement des comptes, Spybox n\u00e9gocie des licences en volume directement aupr\u00e8s des \u00e9diteurs d'outils. Chaque utilisateur dispose de son propre acc\u00e8s." },
  { q: "Puis-je r\u00e9silier \u00e0 tout moment ?", a: "Oui, l'abonnement est sans engagement. Vous pouvez r\u00e9silier depuis votre espace client en un clic. L'acc\u00e8s reste actif jusqu'\u00e0 la fin de la p\u00e9riode pay\u00e9e." },
  { q: "Le code promo GET25 est-il valide ?", a: "Oui, le code GET25 est un code partenaire officiel, v\u00e9rifi\u00e9 r\u00e9guli\u00e8rement. Il fonctionne sur tous les types d'abonnements." },
  { q: "Y a-t-il un support technique ?", a: "Oui, le support Spybox r\u00e9pond par email et chat. Les temps de r\u00e9ponse moyens sont inf\u00e9rieurs \u00e0 24h pour les demandes standard." },
  { q: "Spybox fonctionne-t-il au Maroc ?", a: "Oui, Spybox est accessible partout dans le monde. La plateforme fonctionne depuis n'importe quel navigateur web, sans installation requise." },
  { q: "Comment acc\u00e9der aux outils apr\u00e8s inscription ?", a: "Apr\u00e8s le paiement, votre compte est activ\u00e9 instantan\u00e9ment. Connectez-vous au dashboard et acc\u00e9dez \u00e0 tous les outils depuis le menu principal." },
]

export default function FaqSpybox() {
  return (
    <>
      <ArticleJsonLd title="FAQ Spybox" description="R\u00e9ponses aux questions fr\u00e9quentes sur Spybox." slug="faq-spybox" datePublished="2025-05-01" dateModified="2025-06-01" />
      {/* FAQ Schema */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "FAQPage",
            mainEntity: faqs.map((f) => ({
              "@type": "Question",
              name: f.q,
              acceptedAnswer: { "@type": "Answer", text: f.a },
            })),
          }),
        }}
      />
      <article>
        <PageHeader badge="FAQ" title="Questions fr\u00e9quentes sur Spybox" description="Tout ce que vous devez savoir sur Spybox avant de vous abonner." />

        <section className="border-t border-border py-16">
          <div className="mx-auto max-w-4xl px-4 lg:px-8 space-y-6">
            {faqs.map((f) => (
              <details key={f.q} className="group rounded-xl border border-border bg-card">
                <summary className="cursor-pointer px-6 py-4 font-semibold text-foreground transition-colors hover:text-primary">
                  {f.q}
                </summary>
                <div className="px-6 pb-4 text-base leading-relaxed text-muted-foreground">
                  {f.a}
                </div>
              </details>
            ))}

            <div className="pt-8 text-center">
              <a href={SPYBOX_LINK} target="_blank" rel="noopener noreferrer" className="inline-flex h-12 items-center gap-2 rounded-xl bg-primary px-8 font-bold text-primary-foreground transition-all hover:bg-accent hover:shadow-lg hover:shadow-primary/25">
                S'inscrire \u00e0 Spybox -- Code GET25
                <ArrowRight className="h-4 w-4" aria-hidden="true" />
              </a>
            </div>
          </div>
        </section>
        <CoconLinks current="/faq-spybox" links={[
          { href: "/support-spybox", label: "Support Spybox" },
          { href: "/quest-ce-que-spybox", label: "Qu'est-ce que Spybox ?" },
          { href: "/prix-spybox", label: "Prix Spybox" },
          { href: "/credits-sbc-spybox", label: "Cr\u00e9dits SBC" },
          { href: "/abonnement-spybox-etapes", label: "Comment s'abonner" },
        ]} />
      </article>
    </>
  )
}
