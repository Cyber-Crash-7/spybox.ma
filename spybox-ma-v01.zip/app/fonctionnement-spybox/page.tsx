import type { Metadata } from "next"
import { PageHeader } from "@/components/spybox/page-header"
import { CoconLinks } from "@/components/spybox/cocon-links"
import { ArticleJsonLd } from "@/components/spybox/article-json-ld"

export const metadata: Metadata = {
  title: "Comment Fonctionne Spybox ? Accès, Crédits SBC & Dashboard (2025)",
  description: "Guide complet sur le fonctionnement de Spybox : inscription, crédits SBC, dashboard unifié et accès aux 90+ outils premium e-commerce, SEO et IA en quelques clics.",
  alternates: { canonical: "/fonctionnement-spybox" },
}

export default function Page() {
  return (
    <>
      <ArticleJsonLd
        title="Comment Fonctionne Spybox ? Accès, Crédits SBC & Dashboard"
        description="Guide complet sur le fonctionnement de Spybox : inscription, crédits SBC, dashboard unifié."
        slug="fonctionnement-spybox"
        faq={[
          { q: "Comment accéder aux outils après l'inscription ?", a: "Après inscription, vous accédez au dashboard Spybox et lancez n'importe quel outil en un clic. Les crédits SBC sont débités automatiquement selon l'outil utilisé." },
          { q: "Les crédits SBC sont-ils renouvelés chaque mois ?", a: "Oui, les 100 000 crédits SBC sont réinitialisés automatiquement à chaque cycle de facturation mensuel." },
        ]}
      />
      <PageHeader
        h1="Comment fonctionne Spybox ? Guide complet du système de crédits et d'accès"
        breadcrumb={[
          { label: "Accueil", href: "/" },
          { label: "Qu'est-ce que Spybox", href: "/quest-ce-que-spybox" },
          { label: "Fonctionnement" },
        ]}
        subtitle="De l'inscription à l'utilisation quotidienne : comprenez le modèle Spybox en 5 minutes."
      />
      <article className="mx-auto max-w-4xl px-4 py-12 lg:px-8 lg:py-16">
        <div className="space-y-6 text-base leading-relaxed text-muted-foreground">
          <h2 className="text-2xl font-bold text-foreground">Étape 1 : Inscription et activation</h2>
          <p>
            L'inscription sur Spybox prend moins de 2 minutes. Rendez-vous sur la plateforme, choisissez votre formule d'abonnement (34,99 €/mois avec le code <code className="rounded bg-primary/15 px-1.5 py-0.5 text-sm font-bold text-primary">GET25</code>) et validez votre paiement. Votre compte est activé instantanément et vous accédez immédiatement au dashboard complet.
          </p>

          <h2 className="text-2xl font-bold text-foreground">Étape 2 : Le Dashboard centralisé</h2>
          <p>
            Le tableau de bord Spybox est votre centre de commande. Tous les outils sont classés par catégorie (Product Research, Ad Spy, SEO, IA) avec une barre de recherche pour accéder instantanément à n'importe quelle solution. Chaque outil affiche son coût en crédits SBC, votre solde restant et un historique d'utilisation détaillé.
          </p>
          <p>
            L'interface est responsive et optimisée pour le desktop comme le mobile. Vous pouvez travailler depuis n'importe quel appareil sans installer de logiciel.
          </p>

          <h2 className="text-2xl font-bold text-foreground">Étape 3 : Le système de crédits SBC</h2>
          <p>
            Les crédits SBC (Spybox Credits) sont la monnaie interne de la plateforme. Avec votre abonnement, vous recevez <strong className="text-foreground">100 000 crédits par mois</strong>. Chaque outil consomme un nombre de crédits différent selon sa valeur marchande : une recherche Minea coûte quelques crédits, tandis qu'une génération Midjourney en consomme davantage.
          </p>
          <p>
            Ce système garantit un usage équitable tout en vous laissant la liberté de prioriser les outils selon vos besoins. Si vous utilisez principalement les outils SEO, vos crédits seront alloués en conséquence.
          </p>

          <h2 className="text-2xl font-bold text-foreground">Étape 4 : Utilisation des outils</h2>
          <p>
            Pour lancer un outil, cliquez simplement sur sa carte dans le dashboard. Spybox ouvre une session sécurisée avec les identifiants mutualisés, vous permettant d'utiliser l'outil comme si vous aviez votre propre licence. Les données restent privées et ne sont jamais partagées entre utilisateurs.
          </p>

          <h2 className="text-2xl font-bold text-foreground">Renouvellement et suivi</h2>
          <p>
            Les crédits sont renouvelés automatiquement à chaque cycle mensuel. Un tableau de suivi dans le dashboard vous permet de voir votre consommation en temps réel, avec des alertes quand vous approchez du plafond. Des recharges de crédits supplémentaires sont disponibles si besoin.
          </p>
        </div>

        <CoconLinks
          title="En savoir plus"
          links={[
            { label: "Qu'est-ce que Spybox ?", href: "/quest-ce-que-spybox" },
            { label: "Interface et tableau de bord", href: "/interface-spybox" },
            { label: "Crédits SBC en détail", href: "/credits-sbc-spybox" },
            { label: "S'abonner étape par étape", href: "/abonnement-spybox-etapes" },
            { label: "Tutoriel débutant complet", href: "/tutoriel-spybox-debutant" },
            { label: "Prix officiel Spybox", href: "/prix-spybox" },
          ]}
        />
      </article>
    </>
  )
}
