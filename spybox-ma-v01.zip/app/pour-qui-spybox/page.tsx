import type { Metadata } from "next"
import { PageHeader } from "@/components/spybox/page-header"
import { CoconLinks } from "@/components/spybox/cocon-links"
import { ArticleJsonLd } from "@/components/spybox/article-json-ld"

export const metadata: Metadata = {
  title: "Spybox pour Qui ? Dropshippers, Agences, Freelances & e-Commerçants",
  description: "Découvrez à qui s'adresse Spybox : dropshippers, agences digitales, freelances SEO, e-commerçants et créateurs de contenu. Cas d'usage concrets pour chaque profil.",
  alternates: { canonical: "/pour-qui-spybox" },
}

export default function Page() {
  return (
    <>
      <ArticleJsonLd
        title="Spybox pour Qui ? Dropshippers, Agences, Freelances & e-Commerçants"
        description="Découvrez à qui s'adresse Spybox : dropshippers, agences digitales, freelances SEO."
        slug="pour-qui-spybox"
        faq={[
          { q: "Spybox est-il adapté aux débutants ?", a: "Absolument. L'interface intuitive et les tutoriels intégrés permettent aux débutants de démarrer immédiatement sans compétence technique préalable." },
          { q: "Une agence peut-elle utiliser Spybox pour tous ses clients ?", a: "Oui, le système de crédits SBC permet de travailler sur plusieurs projets clients. Des recharges de crédits sont disponibles pour les usages intensifs." },
        ]}
      />
      <PageHeader
        h1="Spybox pour qui ? Les profils qui tirent le meilleur de la plateforme"
        breadcrumb={[
          { label: "Accueil", href: "/" },
          { label: "Qu'est-ce que Spybox", href: "/quest-ce-que-spybox" },
          { label: "Pour qui ?" },
        ]}
        subtitle="Dropshippers, e-commerçants, agences, freelances ou créateurs de contenu : découvrez comment Spybox s'adapte à votre métier."
      />
      <article className="mx-auto max-w-4xl px-4 py-12 lg:px-8 lg:py-16">
        <div className="space-y-6 text-base leading-relaxed text-muted-foreground">
          <h2 className="text-2xl font-bold text-foreground">Dropshippers et e-commerçants</h2>
          <p>
            C'est le cœur de cible historique de Spybox. Les dropshippers utilisent quotidiennement Minea et ShopHunter pour trouver des produits gagnants, AdSpy et PPAds pour espionner les publicités concurrentes, et les outils IA pour générer des fiches produits, des créatives UGC et des descriptions optimisées. Avec Spybox, un dropshipper économise en moyenne 400 à 800 €/mois par rapport aux abonnements individuels.
          </p>

          <h2 className="text-2xl font-bold text-foreground">Agences digitales</h2>
          <p>
            Les agences gérant plusieurs clients ont besoin d'une stack d'outils complète et évolutive. Spybox centralise les accès SEO (Semrush, Ahrefs, RankerFox), les outils d'espionnage publicitaire et les solutions IA en un seul tableau de bord. Le système de crédits SBC offre la flexibilité de basculer entre outils selon les besoins de chaque client sans surcoût.
          </p>

          <h2 className="text-2xl font-bold text-foreground">Freelances SEO et consultants</h2>
          <p>
            Pour un consultant indépendant, investir dans Semrush (119 €/mois) + Ahrefs (99 €/mois) + Mangools (49 €/mois) représente un budget considérable. Spybox offre l'accès à ces trois solutions plus 87 autres pour 34,99 €/mois. Les crédits mensuels couvrent largement l'analyse de 10 à 20 sites clients par mois.
          </p>

          <h2 className="text-2xl font-bold text-foreground">Créateurs de contenu et influenceurs</h2>
          <p>
            Les créateurs exploitent les outils IA de Spybox pour accélérer leur production : ChatGPT pour le scripting, Midjourney pour les visuels, Runway pour le montage vidéo, ElevenLabs pour le doublage audio. L'ensemble de cette stack IA est inclus dans l'abonnement, sans abonnement additionnel.
          </p>

          <h2 className="text-2xl font-bold text-foreground">Débutants en digital</h2>
          <p>
            Spybox est aussi un excellent point d'entrée pour les personnes qui démarrent dans le e-commerce ou le marketing digital. Au lieu de choisir un seul outil limité par leur budget, ils accèdent directement à la stack complète des professionnels. Les tutoriels intégrés et le support réactif facilitent la prise en main.
          </p>
        </div>

        <CoconLinks
          title="Choisir votre parcours"
          links={[
            { label: "Spybox pour le dropshipping", href: "/spybox-dropshipping" },
            { label: "Tutoriel débutant", href: "/tutoriel-spybox-debutant" },
            { label: "Outils SEO dans Spybox", href: "/rankerfox-spybox" },
            { label: "Outils IA dans Spybox", href: "/spybox-ia-images" },
            { label: "Prix et abonnement", href: "/prix-spybox" },
            { label: "Fonctionnement détaillé", href: "/fonctionnement-spybox" },
          ]}
        />
      </article>
    </>
  )
}
