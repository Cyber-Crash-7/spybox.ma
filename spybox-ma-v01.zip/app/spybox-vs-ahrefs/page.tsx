import type { Metadata } from "next"
import { PageHeader } from "@/components/spybox/page-header"
import { CoconLinks } from "@/components/spybox/cocon-links"
import { ArticleJsonLd } from "@/components/spybox/article-json-ld"
import { ArrowRight, Check, X } from "lucide-react"

const SPYBOX_LINK = "https://spybox.io/?via=sign-ma"

export const metadata: Metadata = {
  title: "Spybox vs Ahrefs -- Comparaison compl\u00e8te SEO 2025",
  description: "Spybox vs Ahrefs : comparaison d\u00e9taill\u00e9e des fonctionnalit\u00e9s SEO, prix et outils inclus. D\u00e9couvrez pourquoi Spybox offre un meilleur rapport qualit\u00e9/prix.",
  alternates: { canonical: "/spybox-vs-ahrefs" },
}

const comparisons = [
  { feature: "Audit technique SEO", spybox: true, ahrefs: true },
  { feature: "Suivi de positions", spybox: true, ahrefs: true },
  { feature: "Analyse de backlinks", spybox: true, ahrefs: true },
  { feature: "Keyword Gap", spybox: true, ahrefs: true },
  { feature: "Espionnage publicitaire", spybox: true, ahrefs: false },
  { feature: "Product Research", spybox: true, ahrefs: false },
  { feature: "Outils IA (ChatGPT, Midjourney)", spybox: true, ahrefs: false },
  { feature: "90+ outils int\u00e9gr\u00e9s", spybox: true, ahrefs: false },
  { feature: "Prix mensuel", spybox: "34,99 \u20ac", ahrefs: "99 \u20ac" },
]

export default function SpyboxVsAhrefs() {
  return (
    <>
      <ArticleJsonLd
        title="Spybox vs Ahrefs -- Comparaison compl\u00e8te SEO 2025"
        description="Comparaison d\u00e9taill\u00e9e Spybox vs Ahrefs : fonctionnalit\u00e9s, prix, outils."
        slug="spybox-vs-ahrefs"
        datePublished="2025-02-05"
        dateModified="2025-06-01"
      />
      <article>
        <PageHeader
          badge="Comparaison SEO"
          title="Spybox vs Ahrefs : le comparatif d\u00e9taill\u00e9 pour choisir votre outil SEO"
          description="Fonctionnalit\u00e9s, prix, outils inclus -- d\u00e9couvrez pourquoi Spybox offre un rapport qualit\u00e9/prix imbattable face \u00e0 Ahrefs."
        />

        <section className="border-t border-border py-16">
          <div className="mx-auto max-w-4xl px-4 lg:px-8 space-y-8 text-base leading-relaxed text-muted-foreground">
            <h2 className="text-2xl font-bold text-foreground">Tableau comparatif Spybox vs Ahrefs</h2>

            <div className="overflow-x-auto rounded-xl border border-border">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border bg-secondary/50">
                    <th className="px-4 py-3 text-left font-semibold text-foreground">Fonctionnalit\u00e9</th>
                    <th className="px-4 py-3 text-center font-semibold text-primary">Spybox</th>
                    <th className="px-4 py-3 text-center font-semibold text-foreground">Ahrefs</th>
                  </tr>
                </thead>
                <tbody>
                  {comparisons.map((row) => (
                    <tr key={row.feature} className="border-b border-border last:border-0">
                      <td className="px-4 py-3 text-foreground">{row.feature}</td>
                      <td className="px-4 py-3 text-center">
                        {typeof row.spybox === "boolean" ? (
                          row.spybox ? <Check className="mx-auto h-5 w-5 text-primary" /> : <X className="mx-auto h-5 w-5 text-destructive" />
                        ) : (
                          <span className="font-bold text-primary">{row.spybox}</span>
                        )}
                      </td>
                      <td className="px-4 py-3 text-center">
                        {typeof row.ahrefs === "boolean" ? (
                          row.ahrefs ? <Check className="mx-auto h-5 w-5 text-primary" /> : <X className="mx-auto h-5 w-5 text-destructive" />
                        ) : (
                          <span className="font-semibold text-foreground">{row.ahrefs}</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <h2 className="text-2xl font-bold text-foreground pt-4">Analyse d\u00e9taill\u00e9e</h2>
            <p>
              Ahrefs est un excellent outil SEO, reconnu pour la qualit\u00e9 de son index de backlinks et la pr\u00e9cision de ses donn\u00e9es. Cependant, son abonnement Lite d\u00e9marre \u00e0 99 \u20ac/mois et ne couvre que le SEO. Si vous avez \u00e9galement besoin d'espionnage publicitaire, de product research ou d'outils IA, il faut ajouter d'autres abonnements.
            </p>
            <p>
              Spybox, \u00e0 34,99 \u20ac/mois, inclut RankerFox (comparable aux fonctionnalit\u00e9s SEO d'Ahrefs) <strong className="text-foreground">plus</strong> l'acc\u00e8s \u00e0 90 autres outils premium. Pour un professionnel qui utilise plusieurs outils au quotidien, l'\u00e9conomie annuelle d\u00e9passe 5 000 \u20ac.
            </p>

            <div className="pt-6 text-center">
              <a href={SPYBOX_LINK} target="_blank" rel="noopener noreferrer" className="inline-flex h-12 items-center gap-2 rounded-xl bg-primary px-8 font-bold text-primary-foreground transition-all hover:bg-accent hover:shadow-lg hover:shadow-primary/25">
                Passer \u00e0 Spybox -- Code GET25
                <ArrowRight className="h-4 w-4" aria-hidden="true" />
              </a>
            </div>
          </div>
        </section>

        <CoconLinks
          current="/spybox-vs-ahrefs"
          links={[
            { href: "/rankerfox-spybox", label: "RankerFox dans Spybox" },
            { href: "/spybox-vs-semrush", label: "Spybox vs Semrush" },
            { href: "/spybox-vs-group-buy", label: "Spybox vs Group Buy" },
            { href: "/meilleurs-outils-ecommerce", label: "Meilleurs outils e-commerce" },
            { href: "/prix-spybox", label: "Prix Spybox" },
          ]}
        />
      </article>
    </>
  )
}
