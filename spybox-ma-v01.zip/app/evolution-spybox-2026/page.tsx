import type { Metadata } from "next"
import { PageHeader } from "@/components/spybox/page-header"
import { CoconLinks } from "@/components/spybox/cocon-links"
import { ArticleJsonLd } from "@/components/spybox/article-json-ld"

export const metadata: Metadata = {
  title: "Évolution Spybox : Nouveaux Outils, Roadmap & Mises à Jour (2025)",
  description: "Suivez l'évolution de Spybox : ajout de nouveaux outils, mises à jour de la plateforme, roadmap publique et historique des améliorations depuis le lancement.",
  alternates: { canonical: "/evolution-spybox-2026" },
}

export default function Page() {
  return (
    <>
      <ArticleJsonLd
        title="Évolution Spybox : Nouveaux Outils, Roadmap & Mises à Jour"
        description="Suivez l'évolution de Spybox : ajout de nouveaux outils, roadmap et mises à jour."
        slug="evolution-spybox-2026"
        faq={[
          { q: "À quelle fréquence Spybox ajoute-t-il de nouveaux outils ?", a: "Spybox ajoute en moyenne 2 à 4 nouveaux outils par mois. Les abonnés sont notifiés par email et via le dashboard à chaque ajout." },
          { q: "Le prix augmente-t-il avec les nouveaux outils ?", a: "Non, le tarif reste à 34,99 €/mois. Les nouveaux outils sont inclus automatiquement dans l'abonnement existant." },
        ]}
      />
      <PageHeader
        h1="Évolution de Spybox : une plateforme en amélioration continue"
        breadcrumb={[
          { label: "Accueil", href: "/" },
          { label: "Qu'est-ce que Spybox", href: "/quest-ce-que-spybox" },
          { label: "Évolution" },
        ]}
        subtitle="De 30 outils au lancement à 90+ aujourd'hui : Spybox grandit avec les besoins de ses utilisateurs."
      />
      <article className="mx-auto max-w-4xl px-4 py-12 lg:px-8 lg:py-16">
        <div className="space-y-6 text-base leading-relaxed text-muted-foreground">
          <h2 className="text-2xl font-bold text-foreground">Une croissance constante depuis le lancement</h2>
          <p>
            Spybox a débuté avec une trentaine d'outils centrés sur le e-commerce et la recherche de produits. En quelques mois, la plateforme a étendu sa couverture au SEO, à l'espionnage publicitaire et à l'intelligence artificielle. Aujourd'hui, plus de 90 outils sont accessibles, et l'objectif affiché est de dépasser les 120 outils d'ici fin 2025.
          </p>

          <h2 className="text-2xl font-bold text-foreground">Les ajouts récents</h2>
          <p>
            Parmi les dernières additions : les outils IA de nouvelle génération (GPT-4o, Claude 3.5, Sora pour la vidéo), des solutions de scraping avancées, et des outils de veille concurrentielle automatisée. Chaque ajout est accompagné d'un tutoriel intégré au dashboard et d'une notification aux abonnés.
          </p>

          <h2 className="text-2xl font-bold text-foreground">Améliorations de la plateforme</h2>
          <p>
            Au-delà des outils, Spybox améliore régulièrement son infrastructure : temps de chargement réduits, nouveau système de favoris, historique d'utilisation enrichi, exports de données améliorés. Le dashboard a été entièrement redessiné en 2024 pour une navigation plus fluide.
          </p>

          <h2 className="text-2xl font-bold text-foreground">Ce qui arrive prochainement</h2>
          <p>
            La roadmap annoncée inclut l'intégration d'outils de marketing automation, de nouvelles solutions d'analyse de données e-commerce, et une API pour connecter Spybox à vos workflows existants. L'équipe travaille également sur un programme de bêta-testeurs pour les abonnés les plus actifs.
          </p>

          <h2 className="text-2xl font-bold text-foreground">Un prix stable malgré l'enrichissement</h2>
          <p>
            Malgré le triplement du nombre d'outils depuis le lancement, le tarif de l'abonnement est resté à 34,99 €/mois. Cette stabilité tarifaire est possible grâce à la croissance de la communauté qui permet de mutualiser davantage les coûts de licence.
          </p>
        </div>

        <CoconLinks
          title="Découvrir la plateforme"
          links={[
            { label: "Qu'est-ce que Spybox ?", href: "/quest-ce-que-spybox" },
            { label: "Les 90+ outils disponibles", href: "/interface-spybox" },
            { label: "Prix et abonnement", href: "/prix-spybox" },
            { label: "Spybox vs Group Buy", href: "/spybox-vs-group-buy" },
            { label: "Support et accompagnement", href: "/support-spybox" },
            { label: "Outils IA de Spybox", href: "/spybox-ia-images" },
          ]}
        />
      </article>
    </>
  )
}
