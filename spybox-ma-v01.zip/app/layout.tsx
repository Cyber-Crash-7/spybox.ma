import type { Metadata, Viewport } from 'next'
import { Inter } from 'next/font/google'
import { PromoBanner } from '@/components/spybox/promo-banner'
import { Header } from '@/components/spybox/header'
import { Footer } from '@/components/spybox/footer'
import './globals.css'

const inter = Inter({
  subsets: ['latin', 'latin-ext'],
  variable: '--font-inter',
  display: 'swap',
})

export const metadata: Metadata = {
  title: {
    default: 'Spybox Officiel – Accès Direct 90+ Outils Premium & Code GET25',
    template: '%s | Spybox.ma',
  },
  description:
    'Accédez à la plateforme Spybox officielle : 90+ outils premium mutualisés (e-commerce, SEO, IA, AdSpy). Abonnement 34,99 €/mois avec 100 000 crédits SBC. Code promo GET25.',
  metadataBase: new URL('https://spybox.ma'),
  openGraph: {
    siteName: 'Spybox',
    locale: 'fr_FR',
    type: 'website',
  },
  robots: {
    index: true,
    follow: true,
  },
}

export const viewport: Viewport = {
  themeColor: '#059669',
  width: 'device-width',
  initialScale: 1,
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="fr" className={inter.variable}>
      <body className="font-sans antialiased bg-background text-foreground">
        <PromoBanner />
        <Header />
        {children}
        <Footer />
      </body>
    </html>
  )
}
