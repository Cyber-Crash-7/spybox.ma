import type { Metadata } from "next"
import { PageHeader } from "@/components/spybox/page-header"
import { CoconLinks } from "@/components/spybox/cocon-links"
import { ArticleJsonLd } from "@/components/spybox/article-json-ld"

export const metadata: Metadata = {
  title: "Interface Spybox : Dashboard, UX & Navigation des 90+ Outils (2025)",
  description: "Présentation complète de l'interface Spybox : dashboard unifié, navigation par catégorie, barre de recherche, suivi des crédits SBC et expérience utilisateur optimisée.",
  alternates: { canonical: "/interface-dashboard-spybox" },
}

export default function Page() {
  return (
    <>
      <ArticleJsonLd
        title="Interface Spybox : Dashboard, UX & Navigation"
        description="Présentation complète de l'interface Spybox : dashboard unifié, navigation par catégorie."
        slug="interface-dashboard-spybox"
        faq={[
          { q: "L'interface Spybox est-elle facile à prendre en main ?", a: "Oui, le dashboard est intuitif avec une navigation par catégorie, une barre de recherche et des tutoriels intégrés pour chaque outil." },
          { q: "Spybox est-il utilisable sur mobile ?", a: "Le dashboard est entièrement responsive et fonctionne sur smartphone et tablette sans application à installer." },
        ]}
      />
      <PageHeader
        h1="Interface Spybox : découvrez le dashboard qui centralise 90+ outils"
        breadcrumb={[
          { label: "Accueil", href: "/" },
          { label: "Qu'est-ce que Spybox", href: "/quest-ce-que-spybox" },
          { label: "Interface" },
        ]}
        subtitle="Un dashboard conçu pour la productivité : accédez à tous vos outils e-commerce, SEO et IA en un clic."
      />
      <article className="mx-auto max-w-4xl px-4 py-12 lg:px-8 lg:py-16">
        <div className="space-y-6 text-base leading-relaxed text-muted-foreground">
          <h2 className="text-2xl font-bold text-foreground">Un dashboard pensé pour l'efficacité</h2>
          <p>
            L'interface Spybox a été conçue pour réduire le temps entre votre idée et l'action. Dès la connexion, le dashboard affiche vos outils favoris, votre solde de crédits SBC, les derniers outils ajoutés et un résumé de votre activité récente. Pas de menu complexe ni de configuration : tout est accessible en 1 à 2 clics maximum.
          </p>

          <h2 className="text-2xl font-bold text-foreground">Navigation par catégorie</h2>
          <p>
            Les 90+ outils sont organisés en catégories claires : Product Research, Ad Spy, SEO & Analytics, Intelligence Artificielle, Vidéo & Audio, Design. Chaque catégorie possède sa propre section avec des filtres avancés pour trouver exactement l'outil dont vous avez besoin. La barre de recherche globale permet également un accès instantané par nom d'outil.
          </p>

          <h2 className="text-2xl font-bold text-foreground">Suivi des crédits en temps réel</h2>
          <p>
            Un widget permanent affiche votre solde SBC et votre consommation du mois. Un graphique de tendance vous aide à anticiper vos besoins : vous voyez immédiatement si votre rythme d'utilisation est compatible avec votre enveloppe mensuelle. Des alertes automatiques vous préviennent à 80 % et 95 % de consommation.
          </p>

          <h2 className="text-2xl font-bold text-foreground">Expérience multi-appareil</h2>
          <p>
            Le dashboard Spybox est entièrement responsive. Sur desktop, vous profitez d'une vue étendue avec panneaux latéraux. Sur tablette et mobile, l'interface s'adapte avec une navigation simplifiée. Aucune application à télécharger : tout fonctionne directement dans votre navigateur.
          </p>

          <h2 className="text-2xl font-bold text-foreground">Mises à jour et nouveaux outils</h2>
          <p>
            Spybox enrichit régulièrement sa bibliothèque. Les nouveaux outils sont signalés par un badge dans le dashboard. Vous recevez également une notification par email à chaque ajout majeur, avec un guide d'utilisation intégré directement dans l'interface.
          </p>
        </div>

        <CoconLinks
          title="Explorer davantage"
          links={[
            { label: "Fonctionnement détaillé de Spybox", href: "/fonctionnement-spybox" },
            { label: "Crédits SBC expliqués", href: "/credits-sbc-spybox" },
            { label: "À qui s'adresse Spybox ?", href: "/spybox-pour-qui" },
            { label: "Tutoriel débutant complet", href: "/tutoriel-spybox-debutant" },
            { label: "Les outils IA de Spybox", href: "/spybox-ia-images" },
            { label: "RankerFox dans Spybox", href: "/rankerfox-spybox" },
          ]}
        />
      </article>
    </>
  )
}
