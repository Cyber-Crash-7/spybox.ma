import type { Metadata } from "next"
import { PageHeader } from "@/components/spybox/page-header"
import { CoconLinks } from "@/components/spybox/cocon-links"
import { ArticleJsonLd } from "@/components/spybox/article-json-ld"
import { PricingCta } from "@/components/spybox/pricing-cta"

export const metadata: Metadata = {
  title: "Prix Spybox 2025 -- Tarifs, abonnement mensuel & annuel, code promo GET25",
  description: "D\u00e9couvrez les tarifs Spybox 2025 : 34,99 \u20ac/mois ou 349,99 \u20ac/an (2 mois offerts) pour 90+ outils premium. Code promo GET25.",
  alternates: { canonical: "/prix-spybox" },
}

export default function PrixSpybox() {
  return (
    <>
      <ArticleJsonLd title="Prix Spybox 2025" description="Tarifs Spybox : mensuel 34,99 \u20ac/mois ou annuel 349,99 \u20ac/an, 90+ outils, code GET25." slug="prix-spybox" datePublished="2025-03-01" dateModified="2025-06-01" />
      <article>
        <PageHeader badge="Tarifs" title="Prix Spybox 2025 : mensuel ou annuel pour 90+ outils premium" description="Deux formules au choix, sans engagement sur le mensuel, ~5 mois offerts sur l'annuel. Code promo GET25 disponible." />

        <PricingCta />

        <section className="border-t border-border py-16">
          <div className="mx-auto max-w-4xl px-4 lg:px-8 space-y-6 text-base leading-relaxed text-muted-foreground">
            <h2 className="text-2xl font-bold text-foreground">Pourquoi ces prix sont imbattables</h2>
            <p>Pour mettre les choses en perspective : un abonnement Semrush Pro co&ucirc;te 129,95 &euro;/mois, Ahrefs Lite 99 &euro;/mois, Minea Starter 97 &euro;/mois, AdSpy 149 $/mois. En cumulant juste ces quatre outils, vous atteignez 475 &euro;/mois soit 5&nbsp;700 &euro;/an.</p>
            <p>Spybox int&egrave;gre ces quatre outils <strong className="text-foreground">plus 86 autres</strong> pour 34,99 &euro;/mois (419,88 &euro;/an) ou 349,99 &euro;/an avec la formule annuelle. L'&eacute;conomie annuelle d&eacute;passe 5&nbsp;200 &euro; en mensuel et 5&nbsp;350 &euro; en annuel.</p>

            <h2 className="text-2xl font-bold text-foreground pt-4">Mensuel vs Annuel : que choisir ?</h2>
            <p>Le <strong className="text-foreground">mensuel &agrave; 34,99 &euro;/mois</strong> est id&eacute;al si vous souhaitez tester Spybox sans engagement ou si votre activit&eacute; est saisonni&egrave;re. Le <strong className="text-foreground">annuel &agrave; 349,99 &euro;/an</strong> (29,17 &euro;/mois) vous fait &eacute;conomiser 2 mois de cotisation, soit 69,89 &euro; par an. Pour les professionnels install&eacute;s, la formule annuelle est le meilleur choix.</p>

            <h2 className="text-2xl font-bold text-foreground pt-4">100&nbsp;000 cr&eacute;dits SBC : comment &ccedil;a marche ?</h2>
            <p>Chaque outil consomme un certain nombre de cr&eacute;dits SBC (Spybox Credits) par utilisation. Les 100&nbsp;000 cr&eacute;dits mensuels sont calibr&eacute;s pour un usage professionnel intensif quotidien. Si vous avez besoin de plus, des recharges sont disponibles. Les cr&eacute;dits sont identiques en mensuel et en annuel.</p>
          </div>
        </section>

        <CoconLinks current="/prix-spybox" links={[
          { href: "/code-promo-get25", label: "Code promo GET25" },
          { href: "/economies-spybox", label: "\u00c9conomies r\u00e9alis\u00e9es" },
          { href: "/abonnement-spybox-etapes", label: "Comment s'abonner" },
          { href: "/simulateur-economies-spybox", label: "Simulateur d'\u00e9conomies" },
          { href: "/credits-sbc-spybox", label: "Cr\u00e9dits SBC" },
        ]} />
      </article>
    </>
  )
}
