import type { Metadata } from "next"
import { PageHeader } from "@/components/spybox/page-header"
import { CoconLinks } from "@/components/spybox/cocon-links"
import { ArticleJsonLd } from "@/components/spybox/article-json-ld"

export const metadata: Metadata = {
  title: "Spybox vs Minea : Comparaison Complète, Prix & Fonctionnalités (2025)",
  description: "Comparaison détaillée Spybox vs Minea : accès aux outils, prix, fonctionnalités, crédits SBC. Pourquoi Spybox à 34,99 €/mois inclut Minea + 89 autres outils.",
  alternates: { canonical: "/spybox-vs-minea-seul" },
}

export default function Page() {
  return (
    <>
      <ArticleJsonLd
        title="Spybox vs Minea : Comparaison Complète, Prix & Fonctionnalités"
        description="Comparaison détaillée Spybox vs Minea : accès, prix et fonctionnalités."
        slug="spybox-vs-minea-seul"
      />
      <PageHeader
        h1="Spybox vs Minea : pourquoi payer 149 €/mois quand 34,99 € suffisent ?"
        breadcrumb={[
          { label: "Accueil", href: "/" },
          { label: "Product Research" },
          { label: "Spybox vs Minea" },
        ]}
        subtitle="Analyse comparative objective entre l'abonnement Minea direct et l'accès via Spybox."
      />
      <article className="mx-auto max-w-4xl px-4 py-12 lg:px-8 lg:py-16">
        <div className="space-y-6 text-base leading-relaxed text-muted-foreground">
          <h2 className="text-2xl font-bold text-foreground">Minea en abonnement direct</h2>
          <p>
            Minea propose trois formules : Starter (49 €/mois) avec des fonctionnalités limitées, Premium (149 €/mois) pour un accès complet, et Business (249 €/mois) pour les agences. La majorité des utilisateurs ont besoin de la formule Premium pour exploiter pleinement le product research, l'analyse de boutiques et le suivi de tendances.
          </p>

          <h2 className="text-2xl font-bold text-foreground">Minea via Spybox</h2>
          <p>
            Dans Spybox, Minea est accessible via le système de crédits SBC pour 34,99 €/mois — le prix de l'abonnement global qui inclut également 89 autres outils. Vous accédez aux fonctionnalités premium de Minea tout en bénéficiant d'AdSpy, Semrush, ChatGPT, Midjourney et l'ensemble de la stack Spybox.
          </p>

          <h2 className="text-2xl font-bold text-foreground">Comparaison des fonctionnalités</h2>
          <div className="overflow-x-auto">
            <table className="mt-4 w-full text-left text-sm">
              <thead>
                <tr className="border-b border-border">
                  <th className="pb-3 pr-6 font-semibold text-foreground">Critère</th>
                  <th className="pb-3 pr-6 font-semibold text-foreground">Minea Premium</th>
                  <th className="pb-3 font-semibold text-primary">Spybox</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                <tr><td className="py-3 pr-6">Prix mensuel</td><td className="py-3 pr-6">149 €</td><td className="py-3 text-primary font-medium">34,99 €</td></tr>
                <tr><td className="py-3 pr-6">Outils inclus</td><td className="py-3 pr-6">1 (Minea)</td><td className="py-3 text-primary font-medium">90+</td></tr>
                <tr><td className="py-3 pr-6">Product Research</td><td className="py-3 pr-6">Oui</td><td className="py-3">Oui (Minea + ShopHunter + autres)</td></tr>
                <tr><td className="py-3 pr-6">Ad Spy</td><td className="py-3 pr-6">Partiel</td><td className="py-3">Complet (AdSpy, PPAds, BigSpy)</td></tr>
                <tr><td className="py-3 pr-6">SEO</td><td className="py-3 pr-6">Non</td><td className="py-3">Oui (RankerFox, Semrush, Ahrefs)</td></tr>
                <tr><td className="py-3 pr-6">Outils IA</td><td className="py-3 pr-6">Non</td><td className="py-3">Oui (ChatGPT, Midjourney, etc.)</td></tr>
                <tr><td className="py-3 pr-6">Code promo</td><td className="py-3 pr-6">—</td><td className="py-3 text-primary font-medium">GET25</td></tr>
              </tbody>
            </table>
          </div>

          <h2 className="text-2xl font-bold text-foreground">Le verdict</h2>
          <p>
            Si vous utilisez uniquement Minea et rien d'autre, l'abonnement direct peut se justifier. Mais dès que vous avez besoin d'un second outil (AdSpy, Semrush, ou un outil IA), Spybox devient mathématiquement imbattable. Pour le prix d'un quart de l'abonnement Minea, vous accédez à l'intégralité de la stack professionnelle.
          </p>
        </div>

        <CoconLinks
          title="Autres comparaisons"
          links={[
            { label: "Spybox vs Semrush", href: "/spybox-vs-semrush" },
            { label: "Spybox vs Ahrefs", href: "/spybox-vs-ahrefs" },
            { label: "Spybox vs Group Buy", href: "/spybox-vs-group-buy" },
            { label: "Minea dans Spybox", href: "/minea-spybox" },
            { label: "Prix officiel Spybox", href: "/prix-spybox" },
            { label: "Économies Spybox", href: "/economies-spybox" },
          ]}
        />
      </article>
    </>
  )
}
