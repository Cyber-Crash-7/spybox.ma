import type { Metadata } from "next"
import { PageHeader } from "@/components/spybox/page-header"
import { CoconLinks } from "@/components/spybox/cocon-links"
import { ArticleJsonLd } from "@/components/spybox/article-json-ld"

export const metadata: Metadata = {
  title: "Crédits SBC Spybox : Fonctionnement, Solde & Optimisation (2025)",
  description: "Tout savoir sur les crédits SBC de Spybox : combien vous en recevez, comment ils sont consommés, comment optimiser leur utilisation et recharger si besoin.",
  alternates: { canonical: "/credits-sbc-spybox" },
}

export default function Page() {
  return (
    <>
      <ArticleJsonLd
        title="Crédits SBC Spybox : Fonctionnement, Solde & Optimisation"
        description="Tout savoir sur les crédits SBC de Spybox : combien vous en recevez, comment ils sont consommés."
        slug="credits-sbc-spybox"
        faq={[
          { q: "Que se passe-t-il si je dépasse mes crédits SBC ?", a: "Vous pouvez acheter des recharges de crédits supplémentaires sans changer de formule, ou attendre le renouvellement mensuel automatique." },
          { q: "Les crédits non utilisés sont-ils reportés ?", a: "Non, les crédits SBC sont remis à zéro et rechargés à 100 000 au début de chaque cycle mensuel." },
        ]}
      />
      <PageHeader
        h1="Crédits SBC Spybox : le système monétaire de la plateforme expliqué"
        breadcrumb={[
          { label: "Accueil", href: "/" },
          { label: "Qu'est-ce que Spybox", href: "/quest-ce-que-spybox" },
          { label: "Crédits SBC" },
        ]}
        subtitle="100 000 crédits par mois, consommation intelligente et recharges disponibles."
      />
      <article className="mx-auto max-w-4xl px-4 py-12 lg:px-8 lg:py-16">
        <div className="space-y-6 text-base leading-relaxed text-muted-foreground">
          <h2 className="text-2xl font-bold text-foreground">Qu'est-ce qu'un crédit SBC ?</h2>
          <p>
            SBC signifie <strong className="text-foreground">Spybox Credit</strong>, la monnaie virtuelle interne de la plateforme. Chaque outil accessible dans Spybox a un coût en SBC qui reflète sa valeur marchande réelle. Les outils les plus coûteux sur le marché (Semrush, Ahrefs) consomment plus de crédits qu'un outil moins onéreux. Ce système permet une tarification équitable et transparente.
          </p>

          <h2 className="text-2xl font-bold text-foreground">Combien de crédits recevez-vous ?</h2>
          <p>
            Chaque abonné Spybox reçoit <strong className="text-foreground">100 000 crédits SBC par mois</strong>, renouvelés automatiquement à la date anniversaire de l'abonnement. Pour un professionnel utilisant 4 à 6 outils quotidiennement, cette enveloppe couvre largement un mois complet d'utilisation intensive.
          </p>

          <h2 className="text-2xl font-bold text-foreground">Comment sont consommés les crédits</h2>
          <p>
            La consommation varie selon le type d'action : une recherche de mots-clés sur RankerFox consomme moins qu'une génération d'image avec Midjourney. Le dashboard affiche en temps réel le coût de chaque action avant que vous ne la déclenchiez, vous permettant de maîtriser votre budget de crédits.
          </p>

          <h2 className="text-2xl font-bold text-foreground">Optimiser sa consommation</h2>
          <p>
            Quelques bonnes pratiques : planifiez vos sessions de recherche pour regrouper les requêtes, utilisez les filtres avancés des outils pour affiner vos résultats du premier coup, et consultez votre historique de consommation hebdomadaire pour identifier les outils les plus gourmands. La plupart des utilisateurs n'atteignent jamais le plafond mensuel.
          </p>

          <h2 className="text-2xl font-bold text-foreground">Recharges de crédits</h2>
          <p>
            Si vous dépassez vos 100 000 crédits mensuels, des packs de recharge sont disponibles directement depuis le dashboard. Pas besoin de changer de formule : vous achetez les crédits supplémentaires au fur et à mesure de vos besoins.
          </p>
        </div>

        <CoconLinks
          title="Aller plus loin"
          links={[
            { label: "Fonctionnement global de Spybox", href: "/fonctionnement-spybox" },
            { label: "Prix et abonnement", href: "/prix-spybox" },
            { label: "Recharges de crédits", href: "/credits-recharges-spybox" },
            { label: "Interface et suivi", href: "/interface-spybox" },
            { label: "Économies réalisées", href: "/economies-spybox" },
            { label: "S'abonner étape par étape", href: "/abonnement-spybox-etapes" },
          ]}
        />
      </article>
    </>
  )
}
