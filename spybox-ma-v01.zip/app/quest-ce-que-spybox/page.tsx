import type { Metadata } from "next"
import { PageHeader } from "@/components/spybox/page-header"
import { CoconLinks } from "@/components/spybox/cocon-links"
import { ArticleJsonLd } from "@/components/spybox/article-json-ld"

export const metadata: Metadata = {
  title: "Qu'est-ce que Spybox ? Plateforme 90+ Outils E-commerce, SEO & IA",
  description: "Découvrez ce qu'est Spybox : une plateforme tout-en-un qui donne accès à plus de 90 outils premium mutualisés pour l'e-commerce, le SEO et l'intelligence artificielle, dès 34,99 €/mois.",
  alternates: { canonical: "/quest-ce-que-spybox" },
}

export default function Page() {
  return (
    <>
      <ArticleJsonLd
        title="Qu'est-ce que Spybox ? Plateforme 90+ Outils E-commerce, SEO & IA"
        description="Découvrez ce qu'est Spybox : une plateforme tout-en-un qui donne accès à plus de 90 outils premium mutualisés."
        slug="quest-ce-que-spybox"
        faq={[
          { q: "Qu'est-ce que Spybox exactement ?", a: "Spybox est une plateforme qui mutualise l'accès à 90+ outils premium (e-commerce, SEO, IA) via un seul abonnement de 34,99 €/mois avec 100 000 crédits SBC." },
          { q: "Combien d'outils sont inclus ?", a: "Plus de 90 outils sont accessibles : Minea, AdSpy, Semrush, Ahrefs, ChatGPT, Midjourney, RankerFox et bien d'autres." },
          { q: "Faut-il des compétences techniques ?", a: "Non. L'interface Spybox est conçue pour être utilisable par tous, du débutant au professionnel confirmé." },
        ]}
      />
      <PageHeader
        h1="Qu'est-ce que Spybox ? La plateforme tout-en-un pour e-commerçants et marketeurs"
        breadcrumb={[
          { label: "Accueil", href: "/" },
          { label: "Qu'est-ce que Spybox ?" },
        ]}
        subtitle="Découvrez comment Spybox révolutionne l'accès aux outils professionnels en mutualisant 90+ solutions premium dans un abonnement unique."
      />
      <article className="mx-auto max-w-4xl px-4 py-12 lg:px-8 lg:py-16">
        <div className="prose-spybox space-y-6 text-base leading-relaxed text-muted-foreground">
          <h2 className="text-2xl font-bold text-foreground">Une solution née d'un constat simple</h2>
          <p>
            Les professionnels du e-commerce et du marketing digital utilisent en moyenne 8 à 12 outils différents au quotidien. Entre les plateformes de recherche de produits, les solutions d'espionnage publicitaire, les suites SEO et les outils d'intelligence artificielle, la facture mensuelle dépasse rapidement 500 € — voire 1 000 € pour une stack complète. Spybox est né de ce constat : pourquoi payer individuellement chaque outil quand on peut mutualiser l'accès ?
          </p>

          <h2 className="text-2xl font-bold text-foreground">Le concept de mutualisation intelligente</h2>
          <p>
            Spybox fonctionne sur un modèle de <strong className="text-foreground">group-buy légal et structuré</strong>. La plateforme négocie des licences en volume auprès des éditeurs d'outils (Minea, AdSpy, Semrush, Ahrefs, ChatGPT, Midjourney…) et redistribue l'accès à ses abonnés via un système de crédits SBC. Chaque membre reçoit 100 000 crédits mensuels, largement suffisants pour un usage professionnel quotidien.
          </p>
          <p>
            Contrairement aux group-buys informels, Spybox est une entreprise structurée avec support client, mises à jour régulières et ajout constant de nouveaux outils. La plateforme compte aujourd'hui plus de 12 000 utilisateurs actifs.
          </p>

          <h2 className="text-2xl font-bold text-foreground">90+ outils répartis en 4 grandes catégories</h2>
          <p>
            La bibliothèque Spybox couvre l'ensemble des besoins d'un professionnel du digital :
          </p>
          <ul className="ml-4 list-disc space-y-2">
            <li><strong className="text-foreground">Product Research</strong> — Minea, ShopHunter, Ecomhunt, Sell The Trend : identifiez les produits gagnants avant la concurrence.</li>
            <li><strong className="text-foreground">Ad Spy</strong> — AdSpy, PPAds, BigSpy, Dropispy : espionnez les publicités sur Facebook, TikTok, Instagram et Pinterest.</li>
            <li><strong className="text-foreground">SEO & Analytics</strong> — RankerFox, Semrush, Ahrefs, Mangools : audit technique, mots-clés, positions, netlinking.</li>
            <li><strong className="text-foreground">Intelligence Artificielle</strong> — ChatGPT, Claude, Midjourney, Runway, ElevenLabs : génération de contenu texte, image, vidéo et audio.</li>
          </ul>

          <h2 className="text-2xl font-bold text-foreground">Un prix unique pour tout accéder</h2>
          <p>
            L'abonnement Spybox est fixé à <strong className="text-foreground">34,99 €/mois</strong> avec le code promo <code className="rounded bg-primary/15 px-1.5 py-0.5 text-sm font-bold text-primary">GET25</code>. Aucun engagement, résiliable à tout moment. L'économie moyenne constatée est de 95 % par rapport à l'achat individuel de chaque outil. Un seul abonnement Minea (149 €/mois) coûte déjà 4 fois plus que l'ensemble de la plateforme Spybox.
          </p>

          <h2 className="text-2xl font-bold text-foreground">Pour qui Spybox est-il fait ?</h2>
          <p>
            Spybox s'adresse aux dropshippers, e-commerçants, consultants SEO, agences digitales, freelances et créateurs de contenu qui souhaitent maximiser leur stack d'outils sans exploser leur budget. Que vous débutiez ou que vous gériez une agence de 20 personnes, la plateforme s'adapte à votre usage grâce au système de crédits flexible.
          </p>
        </div>

        <CoconLinks
          title="Continuez votre découverte"
          links={[
            { label: "Comment fonctionne Spybox", href: "/fonctionnement-spybox" },
            { label: "Interface et tableau de bord", href: "/interface-spybox" },
            { label: "À qui s'adresse Spybox", href: "/spybox-pour-qui" },
            { label: "Système de crédits SBC", href: "/credits-sbc-spybox" },
            { label: "Tarif officiel Spybox", href: "/prix-spybox" },
            { label: "Minea dans Spybox", href: "/minea-spybox" },
          ]}
        />
      </article>
    </>
  )
}
