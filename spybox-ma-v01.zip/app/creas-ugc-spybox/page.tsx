import type { Metadata } from "next"
import { PageHeader } from "@/components/spybox/page-header"
import { CoconLinks } from "@/components/spybox/cocon-links"
import { ArticleJsonLd } from "@/components/spybox/article-json-ld"

export const metadata: Metadata = {
  title: "Créatives UGC avec Spybox : Générer des Publicités IA Performantes",
  description: "Apprenez à créer des publicités UGC performantes avec les outils IA de Spybox : ChatGPT pour le script, Midjourney pour les visuels, Runway pour le montage vidéo.",
  alternates: { canonical: "/creas-ugc-spybox" },
}

export default function Page() {
  return (
    <>
      <ArticleJsonLd title="Créatives UGC avec Spybox : Générer des Publicités IA Performantes" description="Créez des publicités UGC performantes avec les outils IA de Spybox." slug="creas-ugc-spybox" />
      <PageHeader h1="Créer des publicités UGC performantes avec les outils IA de Spybox" breadcrumb={[{ label: "Accueil", href: "/" }, { label: "Ad Spy" }, { label: "Créatives UGC" }]} subtitle="Du script au montage final : produisez des créatives publicitaires qui convertissent grâce à l'IA." />
      <article className="mx-auto max-w-4xl px-4 py-12 lg:px-8 lg:py-16">
        <div className="space-y-6 text-base leading-relaxed text-muted-foreground">
          <h2 className="text-2xl font-bold text-foreground">L'UGC : le format publicitaire roi</h2>
          <p>Le contenu généré par les utilisateurs (UGC) est le format publicitaire le plus performant en e-commerce. Les vidéos UGC authentiques convertissent 4 à 8 fois mieux que les publicités classiques. Elles créent un sentiment de confiance et de proximité que les visuels léchés ne peuvent pas reproduire.</p>

          <h2 className="text-2xl font-bold text-foreground">Étape 1 : S'inspirer avec AdSpy et PPAds</h2>
          <p>Avant de créer, analysez. Utilisez AdSpy et PPAds dans Spybox pour identifier les créatives UGC qui performent le mieux dans votre niche. Notez les hooks d'accroche (les 3 premières secondes), la structure narrative, les arguments de vente et les appels à l'action. Ces insights guideront vos propres créatives.</p>

          <h2 className="text-2xl font-bold text-foreground">Étape 2 : Scripting avec ChatGPT</h2>
          <p>Ouvrez ChatGPT dans Spybox et demandez-lui de rédiger un script UGC basé sur vos observations. Précisez le produit, le problème résolu, le ton souhaité (authentique, enthousiaste, éducatif) et la durée cible. ChatGPT produit des scripts structurés avec hook, démonstration, bénéfices et CTA en quelques secondes.</p>

          <h2 className="text-2xl font-bold text-foreground">Étape 3 : Visuels et vidéo avec Midjourney et Runway</h2>
          <p>Midjourney génère des visuels produit photoréalistes et des mises en situation lifestyle. Runway permet de créer des clips vidéo à partir d'images ou de descriptions texte. Combinez les deux pour produire une créative vidéo complète sans tournage ni acteur. ElevenLabs ajoute une voix-off naturelle si nécessaire.</p>

          <h2 className="text-2xl font-bold text-foreground">Étape 4 : Tester et itérer</h2>
          <p>Lancez vos créatives, analysez les résultats, puis retournez dans Spybox pour affiner. Le cycle complet — espionnage, création, test, optimisation — se fait entièrement depuis la plateforme, ce qui réduit considérablement le temps entre chaque itération.</p>
        </div>
        <CoconLinks title="Ressources créatives" links={[
          { label: "AdSpy et PPAds", href: "/adspy-ppads-spybox" },
          { label: "Outils IA images", href: "/spybox-ia-images" },
          { label: "Outils IA vidéo", href: "/spybox-ia-video" },
          { label: "Meilleures créatives", href: "/meilleures-creas-spybox" },
          { label: "Optimiser son ROAS", href: "/roas-spybox" },
          { label: "ChatGPT dans Spybox", href: "/chatgpt-spybox" },
        ]} />
      </article>
    </>
  )
}
