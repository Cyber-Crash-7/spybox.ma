import type { Metadata } from "next"
import { PageHeader } from "@/components/spybox/page-header"
import { CoconLinks } from "@/components/spybox/cocon-links"
import { ArticleJsonLd } from "@/components/spybox/article-json-ld"

export const metadata: Metadata = {
  title: "Spybox pour le Dropshipping : La Stack Complète pour Réussir (2025)",
  description: "Découvrez comment Spybox révolutionne le dropshipping : product research, ad spy, outils IA et SEO réunis dans un seul abonnement à 34,99 €/mois.",
  alternates: { canonical: "/spybox-dropshipping" },
}

export default function Page() {
  return (
    <>
      <ArticleJsonLd
        title="Spybox pour le Dropshipping : La Stack Complète pour Réussir"
        description="Comment Spybox révolutionne le dropshipping avec tous les outils nécessaires."
        slug="spybox-dropshipping"
      />
      <PageHeader
        h1="Spybox pour le dropshipping : tous les outils dont vous avez besoin"
        breadcrumb={[
          { label: "Accueil", href: "/" },
          { label: "Product Research" },
          { label: "Dropshipping" },
        ]}
        subtitle="De la recherche de produits à la création publicitaire : Spybox couvre l'intégralité du workflow dropshipping."
      />
      <article className="mx-auto max-w-4xl px-4 py-12 lg:px-8 lg:py-16">
        <div className="space-y-6 text-base leading-relaxed text-muted-foreground">
          <h2 className="text-2xl font-bold text-foreground">Le dropshipping en 2025 : un métier d'outils</h2>
          <p>
            Le dropshipping moderne ne se résume plus à trouver un produit et lancer une pub. C'est un métier qui exige une stack d'outils complète : recherche de produits, espionnage publicitaire, création de contenu, optimisation SEO et analyse de données. Sans ces outils, vous opérez à l'aveugle face à des concurrents armés jusqu'aux dents.
          </p>

          <h2 className="text-2xl font-bold text-foreground">La stack dropshipping idéale dans Spybox</h2>
          <p>
            Spybox réunit tous les maillons de la chaîne : <strong className="text-foreground">Minea</strong> et <strong className="text-foreground">ShopHunter</strong> pour le product research, <strong className="text-foreground">AdSpy</strong> et <strong className="text-foreground">PPAds</strong> pour l'espionnage publicitaire, <strong className="text-foreground">ChatGPT</strong> et <strong className="text-foreground">Midjourney</strong> pour la création de contenu, <strong className="text-foreground">RankerFox</strong> pour le SEO. Le tout pour 34,99 €/mois au lieu de 800+ € en abonnements séparés.
          </p>

          <h2 className="text-2xl font-bold text-foreground">Workflow quotidien type</h2>
          <p>
            Matin : scan Minea pour les nouveaux produits viraux, validation sur ShopHunter. Midi : analyse des meilleures créatives sur AdSpy, création de vos propres visuels avec les outils IA. Après-midi : lancement des campagnes publicitaires, optimisation des pages produits avec ChatGPT. Soir : suivi des positions SEO sur RankerFox. Tout cela depuis un seul dashboard.
          </p>

          <h2 className="text-2xl font-bold text-foreground">Économie réelle pour un dropshipper</h2>
          <p>
            Un dropshipper qui utilise Minea (149 €), AdSpy (149 €), ChatGPT Pro (20 €) et un outil SEO (99 €) dépense minimum 417 €/mois. Avec Spybox à 34,99 €/mois + le code <code className="rounded bg-primary/15 px-1.5 py-0.5 text-sm font-bold text-primary">GET25</code>, l'économie mensuelle dépasse 380 €. Sur un an, cela représente plus de 4 500 € réinvestissables dans vos campagnes publicitaires.
          </p>

          <h2 className="text-2xl font-bold text-foreground">Du débutant au professionnel</h2>
          <p>
            Que vous lanciez votre première boutique ou que vous gériez un portefeuille de 10 sites e-commerce, Spybox s'adapte. Les débutants apprécient l'accès à tous les outils sans investissement initial massif. Les professionnels valorisent la centralisation et l'économie de temps liée au dashboard unifié.
          </p>
        </div>

        <CoconLinks
          title="Approfondir votre stratégie"
          links={[
            { label: "Minea dans Spybox", href: "/minea-spybox" },
            { label: "AdSpy et PPAds", href: "/adspy-ppads-spybox" },
            { label: "Produits viraux", href: "/produits-viraux-spybox" },
            { label: "Workflow dropshipping complet", href: "/workflow-dropshipping-spybox" },
            { label: "Optimisation de publicités", href: "/optimisation-ads-spybox" },
            { label: "Économies avec Spybox", href: "/economies-spybox" },
          ]}
        />
      </article>
    </>
  )
}
