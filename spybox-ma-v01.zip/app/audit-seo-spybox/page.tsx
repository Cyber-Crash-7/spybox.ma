import type { Metadata } from "next"
import { PageHeader } from "@/components/spybox/page-header"
import { CoconLinks } from "@/components/spybox/cocon-links"
import { ArticleJsonLd } from "@/components/spybox/article-json-ld"
import { ArrowRight } from "lucide-react"

const SPYBOX_LINK = "https://spybox.io/?via=sign-ma"

export const metadata: Metadata = {
  title: "Audit SEO Spybox -- Analyse technique compl\u00e8te de votre site",
  description: "Lancez un audit SEO technique complet avec RankerFox dans Spybox : erreurs, vitesse, Core Web Vitals, balises. Inclus dans l'abonnement 34,99 \u20ac/mois.",
  alternates: { canonical: "/audit-seo-spybox" },
}

export default function AuditSeoSpybox() {
  return (
    <>
      <ArticleJsonLd
        title="Audit SEO Spybox -- Analyse technique compl\u00e8te de votre site"
        description="Audit SEO technique avec RankerFox dans Spybox : crawl, erreurs, vitesse, balises."
        slug="audit-seo-spybox"
        datePublished="2025-01-20"
        dateModified="2025-06-01"
      />
      <article>
        <PageHeader
          badge="SEO RankerFox"
          title="Audit SEO technique : identifiez et corrigez les freins \u00e0 votre r\u00e9f\u00e9rencement"
          description="RankerFox crawle votre site et d\u00e9tecte les erreurs techniques qui p\u00e9nalisent vos positions Google."
        />

        <section className="border-t border-border py-16">
          <div className="mx-auto max-w-4xl px-4 lg:px-8 space-y-6 text-base leading-relaxed text-muted-foreground">
            <h2 className="text-2xl font-bold text-foreground">Pourquoi r\u00e9aliser un audit SEO technique ?</h2>
            <p>
              Un site techniquement d\u00e9faillant ne peut pas bien se positionner, m\u00eame avec un contenu excellent. Les erreurs 404, les pages lentes, les balises title/meta description manquantes, les probl\u00e8mes de maillage interne -- chaque d\u00e9faut technique co\u00fbte des positions dans les SERPs.
            </p>
            <p>
              L'audit SEO de RankerFox effectue un crawl complet de votre site et g\u00e9n\u00e8re un rapport structur\u00e9 avec un score de sant\u00e9 global. Chaque probl\u00e8me est class\u00e9 par gravit\u00e9 (critique, important, mineur) avec des recommandations actionables.
            </p>

            <h2 className="text-2xl font-bold text-foreground pt-6">Ce que l'audit analyse</h2>
            <ul className="list-disc pl-6 space-y-2">
              <li><strong className="text-foreground">Performance :</strong> temps de chargement, Core Web Vitals (LCP, FID, CLS), poids des pages</li>
              <li><strong className="text-foreground">Indexation :</strong> pages non index\u00e9es, robots.txt, sitemap XML, erreurs de crawl</li>
              <li><strong className="text-foreground">Contenu :</strong> balises title et H1 dupliqu\u00e9es ou manquantes, thin content, contenu dupliquu00e9</li>
              <li><strong className="text-foreground">Liens :</strong> liens cass\u00e9s internes/externes, redirections en cha\u00eene, profondeur de page</li>
              <li><strong className="text-foreground">Mobile :</strong> compatibilit\u00e9 responsive, taille des \u00e9l\u00e9ments cliquables, viewport</li>
            </ul>

            <div className="pt-6 text-center">
              <a href={SPYBOX_LINK} target="_blank" rel="noopener noreferrer" className="inline-flex h-12 items-center gap-2 rounded-xl bg-primary px-8 font-bold text-primary-foreground transition-all hover:bg-accent hover:shadow-lg hover:shadow-primary/25">
                Lancer un audit SEO -- Code GET25
                <ArrowRight className="h-4 w-4" aria-hidden="true" />
              </a>
            </div>
          </div>
        </section>

        <CoconLinks
          current="/audit-seo-spybox"
          links={[
            { href: "/rankerfox-spybox", label: "RankerFox dans Spybox" },
            { href: "/keyword-gap-spybox", label: "Keyword Gap" },
            { href: "/netlinking-spybox", label: "Strat\u00e9gie de netlinking" },
            { href: "/suivi-positions-spybox", label: "Suivi de positions" },
            { href: "/", label: "Accueil Spybox" },
          ]}
        />
      </article>
    </>
  )
}
