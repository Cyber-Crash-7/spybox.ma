import type { Metadata } from "next"
import { PageHeader } from "@/components/spybox/page-header"
import { CoconLinks } from "@/components/spybox/cocon-links"
import { ArticleJsonLd } from "@/components/spybox/article-json-ld"
import { ArrowRight } from "lucide-react"

const SPYBOX_LINK = "https://spybox.io/?via=sign-ma"

export const metadata: Metadata = {
  title: "Tutoriel RankerFox Spybox -- Guide complet de l'outil SEO",
  description: "Tutoriel complet RankerFox dans Spybox : audit, keyword gap, backlinks, suivi de positions. Apprenez \u00e0 ma\u00eetriser l'outil SEO int\u00e9gr\u00e9.",
  alternates: { canonical: "/tuto-rankerfox-spybox" },
}

export default function TutoRankerFoxSpybox() {
  return (
    <>
      <ArticleJsonLd title="Tutoriel RankerFox Spybox" description="Guide complet RankerFox : audit, keywords, backlinks, positions." slug="tuto-rankerfox-spybox" datePublished="2025-04-15" dateModified="2025-06-01" />
      <article>
        <PageHeader badge="Tutoriel SEO" title="Tutoriel RankerFox : ma\u00eetrisez l'outil SEO de Spybox" description="Guide pas \u00e0 pas pour utiliser chaque fonctionnalit\u00e9 de RankerFox et optimiser votre r\u00e9f\u00e9rencement naturel." />

        <section className="border-t border-border py-16">
          <div className="mx-auto max-w-4xl px-4 lg:px-8 space-y-6 text-base leading-relaxed text-muted-foreground">
            <h2 className="text-2xl font-bold text-foreground">Acc\u00e9der \u00e0 RankerFox</h2>
            <p>Depuis le dashboard Spybox, cliquez sur "SEO & Analytics" dans le menu lat\u00e9ral, puis s\u00e9lectionnez RankerFox. L'interface s'ouvre avec quatre modules : Audit, Keywords, Backlinks et Rank Tracker.</p>

            <h2 className="text-2xl font-bold text-foreground pt-6">Module Audit</h2>
            <p>Entrez l'URL de votre site et lancez un crawl. RankerFox analyse toutes les pages accessibles et g\u00e9n\u00e8re un score de sant\u00e9 global. Les probl\u00e8mes sont class\u00e9s par priorit\u00e9 : critique (rouge), important (orange), mineur (jaune). Cliquez sur chaque probl\u00e8me pour voir les pages concern\u00e9es et les recommandations de correction.</p>

            <h2 className="text-2xl font-bold text-foreground pt-6">Module Keywords</h2>
            <p>Saisissez un domaine ou un mot-cl\u00e9 semence pour d\u00e9couvrir des opportunit\u00e9s. Filtrez par volume de recherche, difficult\u00e9 et CPC. La fonction Keyword Gap permet de comparer jusqu'\u00e0 5 domaines simultan\u00e9ment pour identifier les mots-cl\u00e9s o\u00f9 vous \u00eates absent.</p>

            <h2 className="text-2xl font-bold text-foreground pt-6">Module Backlinks</h2>
            <p>Analysez le profil de liens de n'importe quel domaine. Identifiez les domaines r\u00e9f\u00e9rents les plus puissants, les ancres de liens utilis\u00e9es, et les pages qui re\u00e7oivent le plus de liens. Croisez les profils de vos concurrents pour trouver des opportunit\u00e9s de prospection.</p>

            <h2 className="text-2xl font-bold text-foreground pt-6">Module Rank Tracker</h2>
            <p>Ajoutez vos mots-cl\u00e9s cibles et d\u00e9finissez la localisation g\u00e9ographique. RankerFox v\u00e9rifie vos positions quotidiennement et g\u00e9n\u00e8re des courbes d'\u00e9volution. Configurez des alertes email pour \u00eatre notifi\u00e9 en cas de variation importante.</p>

            <div className="pt-6 text-center">
              <a href={SPYBOX_LINK} target="_blank" rel="noopener noreferrer" className="inline-flex h-12 items-center gap-2 rounded-xl bg-primary px-8 font-bold text-primary-foreground transition-all hover:bg-accent hover:shadow-lg hover:shadow-primary/25">
                Essayer RankerFox -- Code GET25
                <ArrowRight className="h-4 w-4" aria-hidden="true" />
              </a>
            </div>
          </div>
        </section>
        <CoconLinks current="/tuto-rankerfox-spybox" links={[
          { href: "/rankerfox-spybox", label: "RankerFox dans Spybox" },
          { href: "/workflow-seo-spybox", label: "Workflow SEO complet" },
          { href: "/audit-seo-spybox", label: "Audit SEO technique" },
          { href: "/keyword-gap-spybox", label: "Keyword Gap" },
          { href: "/tuto-debutant-spybox", label: "Tutoriel d\u00e9butant" },
        ]} />
      </article>
    </>
  )
}
