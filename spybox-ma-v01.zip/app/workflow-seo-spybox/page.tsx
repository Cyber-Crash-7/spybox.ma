import type { Metadata } from "next"
import { PageHeader } from "@/components/spybox/page-header"
import { CoconLinks } from "@/components/spybox/cocon-links"
import { ArticleJsonLd } from "@/components/spybox/article-json-ld"
import { ArrowRight } from "lucide-react"

const SPYBOX_LINK = "https://spybox.io/?via=sign-ma"

export const metadata: Metadata = {
  title: "Workflow SEO Spybox -- Strat\u00e9gie SEO compl\u00e8te avec RankerFox et IA",
  description: "Workflow SEO complet avec Spybox : audit technique, keyword research, r\u00e9daction IA, netlinking et suivi de positions. Tout dans une seule plateforme.",
  alternates: { canonical: "/workflow-seo-spybox" },
}

const steps = [
  { step: "1", title: "Audit technique", tool: "RankerFox", desc: "Identifiez et corrigez les erreurs techniques qui freinent votre r\u00e9f\u00e9rencement : vitesse, balises, liens cass\u00e9s." },
  { step: "2", title: "Keyword research & gap", tool: "RankerFox", desc: "D\u00e9couvrez les mots-cl\u00e9s \u00e0 cibler en priorit\u00e9 et ceux que vos concurrents exploitent sans vous." },
  { step: "3", title: "R\u00e9daction de contenu", tool: "ChatGPT / Claude", desc: "G\u00e9n\u00e9rez des articles optimis\u00e9s SEO, des m\u00e9ta descriptions et des titres accrocheurs \u00e0 l'aide des outils IA." },
  { step: "4", title: "Strat\u00e9gie de netlinking", tool: "RankerFox", desc: "Analysez les backlinks concurrents et identifiez les sites \u00e0 prospecter pour renforcer votre autorit\u00e9." },
  { step: "5", title: "Suivi de positions", tool: "RankerFox", desc: "Mesurez l'impact de chaque action en suivant vos positions au quotidien sur vos mots-cl\u00e9s cibles." },
]

export default function WorkflowSeoSpybox() {
  return (
    <>
      <ArticleJsonLd title="Workflow SEO Spybox" description="Strat\u00e9gie SEO compl\u00e8te de l'audit au suivi de positions avec Spybox." slug="workflow-seo-spybox" datePublished="2025-04-10" dateModified="2025-06-01" />
      <article>
        <PageHeader badge="Tutoriel" title="Workflow SEO complet : de l'audit au suivi de positions avec Spybox" description="5 \u00e9tapes pour construire une strat\u00e9gie SEO performante en utilisant RankerFox et les outils IA de Spybox." />

        <section className="border-t border-border py-16">
          <div className="mx-auto max-w-4xl px-4 lg:px-8 space-y-6">
            {steps.map((s) => (
              <div key={s.step} className="flex gap-5">
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-primary text-lg font-bold text-primary-foreground">{s.step}</div>
                <div>
                  <h2 className="text-lg font-bold text-foreground">{s.title} <span className="text-sm font-normal text-primary">({s.tool})</span></h2>
                  <p className="mt-1 text-base leading-relaxed text-muted-foreground">{s.desc}</p>
                </div>
              </div>
            ))}
            <div className="pt-8 text-center">
              <a href={SPYBOX_LINK} target="_blank" rel="noopener noreferrer" className="inline-flex h-12 items-center gap-2 rounded-xl bg-primary px-8 font-bold text-primary-foreground transition-all hover:bg-accent hover:shadow-lg hover:shadow-primary/25">
                Optimiser mon SEO -- Code GET25
                <ArrowRight className="h-4 w-4" aria-hidden="true" />
              </a>
            </div>
          </div>
        </section>
        <CoconLinks current="/workflow-seo-spybox" links={[
          { href: "/rankerfox-spybox", label: "RankerFox dans Spybox" },
          { href: "/audit-seo-spybox", label: "Audit SEO technique" },
          { href: "/keyword-gap-spybox", label: "Keyword Gap" },
          { href: "/tuto-debutant-spybox", label: "Tutoriel d\u00e9butant" },
          { href: "/tuto-rankerfox-spybox", label: "Tuto RankerFox" },
        ]} />
      </article>
    </>
  )
}
