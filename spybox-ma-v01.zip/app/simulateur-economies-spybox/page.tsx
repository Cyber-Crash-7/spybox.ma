import type { Metadata } from "next"
import { PageHeader } from "@/components/spybox/page-header"
import { CoconLinks } from "@/components/spybox/cocon-links"
import { ArticleJsonLd } from "@/components/spybox/article-json-ld"
import { SimulateurWidget } from "@/components/spybox/simulateur-widget"

export const metadata: Metadata = {
  title: "Simulateur d'\u00e9conomies Spybox -- Calculez votre \u00e9conomie annuelle",
  description: "Calculez combien vous \u00e9conomisez avec Spybox par rapport aux abonnements s\u00e9par\u00e9s. 90+ outils pour 34,99 \u20ac/mois vs 8 000 \u20ac+/an en licences individuelles.",
  alternates: { canonical: "/simulateur-economies-spybox" },
}

export default function SimulateurEconomiesSpybox() {
  return (
    <>
      <ArticleJsonLd title="Simulateur d'\u00e9conomies Spybox" description="Calculez votre \u00e9conomie annuelle avec Spybox." slug="simulateur-economies-spybox" datePublished="2025-02-25" dateModified="2025-06-01" />
      <article>
        <PageHeader badge="Outil interactif" title="Simulateur d'\u00e9conomies : combien \u00e9conomisez-vous avec Spybox ?" description="S\u00e9lectionnez les outils que vous utilisez actuellement et d\u00e9couvrez votre \u00e9conomie annuelle en passant \u00e0 Spybox." />
        <section className="border-t border-border py-16">
          <div className="mx-auto max-w-4xl px-4 lg:px-8">
            <SimulateurWidget />
          </div>
        </section>
        <CoconLinks current="/simulateur-economies-spybox" links={[
          { href: "/prix-spybox", label: "Prix Spybox" },
          { href: "/code-promo-spybox", label: "Code promo GET25" },
          { href: "/spybox-vs-semrush", label: "Spybox vs Semrush" },
          { href: "/spybox-vs-ahrefs", label: "Spybox vs Ahrefs" },
          { href: "/meilleurs-outils-ecommerce", label: "Meilleurs outils e-commerce" },
        ]} />
      </article>
    </>
  )
}
