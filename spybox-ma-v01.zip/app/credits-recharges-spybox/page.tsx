import type { Metadata } from "next"
import { PageHeader } from "@/components/spybox/page-header"
import { CoconLinks } from "@/components/spybox/cocon-links"
import { ArticleJsonLd } from "@/components/spybox/article-json-ld"
import { ArrowRight } from "lucide-react"

const SPYBOX_LINK = "https://spybox.io/?via=sign-ma"

export const metadata: Metadata = {
  title: "Cr\u00e9dits et recharges Spybox -- Compl\u00e9ter vos SBC",
  description: "Tout savoir sur les cr\u00e9dits SBC Spybox : 100 000 cr\u00e9dits inclus, options de recharge, co\u00fbt par outil. Optimisez votre consommation.",
  alternates: { canonical: "/credits-recharges-spybox" },
}

export default function CreditsRechargesSpybox() {
  return (
    <>
      <ArticleJsonLd title="Cr\u00e9dits et recharges Spybox" description="Cr\u00e9dits SBC, recharges et optimisation de la consommation Spybox." slug="credits-recharges-spybox" datePublished="2025-03-20" dateModified="2025-06-01" />
      <article>
        <PageHeader badge="Cr\u00e9dits SBC" title="Cr\u00e9dits SBC et recharges : optimisez votre consommation Spybox" description="100 000 cr\u00e9dits inclus chaque mois. Besoin de plus ? Des recharges sont disponibles pour les utilisateurs intensifs." />

        <section className="border-t border-border py-16">
          <div className="mx-auto max-w-4xl px-4 lg:px-8 space-y-6 text-base leading-relaxed text-muted-foreground">
            <h2 className="text-2xl font-bold text-foreground">Comment fonctionnent les cr\u00e9dits SBC ?</h2>
            <p>Chaque outil dans Spybox consomme un nombre d\u00e9fini de cr\u00e9dits SBC (Spybox Credits) par action. Par exemple, une recherche de produit sur Minea consomme entre 5 et 20 SBC selon la complexit\u00e9 de la requ\u00eate, tandis qu'une g\u00e9n\u00e9ration d'image via Midjourney consomme environ 50 SBC.</p>
            <p>Avec 100 000 cr\u00e9dits mensuels, un utilisateur professionnel peut r\u00e9aliser des centaines de recherches, analyses et g\u00e9n\u00e9rations de contenu chaque jour sans jamais manquer de cr\u00e9dits.</p>

            <h2 className="text-2xl font-bold text-foreground pt-6">Options de recharge</h2>
            <p>Si vous atteignez la limite de vos 100 000 cr\u00e9dits mensuels (ce qui arrive principalement aux agences g\u00e9rant plusieurs clients), Spybox propose des packs de recharge additionnels. Les cr\u00e9dits de recharge s'ajoutent \u00e0 votre solde existant et restent valables jusqu'\u00e0 la fin du mois en cours.</p>

            <h2 className="text-2xl font-bold text-foreground pt-6">Astuces pour optimiser vos cr\u00e9dits</h2>
            <ul className="list-disc pl-6 space-y-2">
              <li>Planifiez vos recherches : regroupez vos analyses par session pour \u00e9viter les requ\u00eates redondantes</li>
              <li>Utilisez les filtres : des requ\u00eates cibl\u00e9es consomment moins de cr\u00e9dits que des recherches larges</li>
              <li>Exportez vos r\u00e9sultats : sauvegardez les donn\u00e9es en CSV pour \u00e9viter de relancer les m\u00eames analyses</li>
              <li>Priorisez les outils \u00e0 fort ROI : concentrez vos cr\u00e9dits sur les outils qui g\u00e9n\u00e8rent le plus de valeur pour votre business</li>
            </ul>

            <div className="pt-6 text-center">
              <a href={SPYBOX_LINK} target="_blank" rel="noopener noreferrer" className="inline-flex h-12 items-center gap-2 rounded-xl bg-primary px-8 font-bold text-primary-foreground transition-all hover:bg-accent hover:shadow-lg hover:shadow-primary/25">
                Acc\u00e9der \u00e0 Spybox -- Code GET25
                <ArrowRight className="h-4 w-4" aria-hidden="true" />
              </a>
            </div>
          </div>
        </section>
        <CoconLinks current="/credits-recharges-spybox" links={[
          { href: "/credits-sbc-spybox", label: "Comprendre les cr\u00e9dits SBC" },
          { href: "/prix-spybox", label: "Prix Spybox" },
          { href: "/fonctionnement-spybox", label: "Fonctionnement de Spybox" },
          { href: "/economies-spybox", label: "\u00c9conomies r\u00e9alis\u00e9es" },
          { href: "/faq-spybox", label: "FAQ Spybox" },
        ]} />
      </article>
    </>
  )
}
