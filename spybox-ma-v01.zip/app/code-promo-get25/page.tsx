import type { Metadata } from "next"
import { PageHeader } from "@/components/spybox/page-header"
import { CoconLinks } from "@/components/spybox/cocon-links"
import { ArticleJsonLd } from "@/components/spybox/article-json-ld"
import { ArrowRight } from "lucide-react"

const SPYBOX_LINK = "https://spybox.io/?via=sign-ma"

export const metadata: Metadata = {
  title: "Code Promo Spybox GET25 -- R\u00e9duction valide juin 2025",
  description: "Utilisez le code promo Spybox GET25 pour obtenir une r\u00e9duction sur votre abonnement. Code valide, v\u00e9rifi\u00e9 et cumulable avec le tarif 34,99 \u20ac/mois.",
  alternates: { canonical: "/code-promo-get25" },
}

export default function CodePromoSpybox() {
  return (
    <>
      <ArticleJsonLd title="Code Promo Spybox GET25" description="Code promo GET25 pour r\u00e9duction Spybox." slug="code-promo-get25" datePublished="2025-03-05" dateModified="2025-06-01" />
      <article>
        <PageHeader badge="Code promo" title="Code promo Spybox : GET25 -- votre r\u00e9duction exclusive" description="Appliquez le code GET25 lors de votre inscription et b\u00e9n\u00e9ficiez d'une r\u00e9duction imm\u00e9diate sur votre abonnement Spybox." />

        <section className="border-t border-border py-16">
          <div className="mx-auto max-w-4xl px-4 lg:px-8 space-y-6 text-base leading-relaxed text-muted-foreground">
            {/* Code highlight */}
            <div className="mx-auto max-w-sm rounded-2xl border-2 border-primary bg-primary/5 p-8 text-center">
              <p className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">Votre code promo</p>
              <p className="mt-4 text-4xl font-extrabold tracking-widest text-primary">GET25</p>
              <p className="mt-3 text-sm text-muted-foreground">Valide sur tous les abonnements Spybox</p>
              <a href={SPYBOX_LINK} target="_blank" rel="noopener noreferrer" className="mt-6 inline-flex h-12 w-full items-center justify-center gap-2 rounded-xl bg-primary font-bold text-primary-foreground transition-all hover:bg-accent hover:shadow-lg hover:shadow-primary/25">
                Utiliser le code GET25
                <ArrowRight className="h-4 w-4" aria-hidden="true" />
              </a>
            </div>

            <h2 className="text-2xl font-bold text-foreground pt-6">Comment utiliser le code promo GET25 ?</h2>
            <ol className="list-decimal pl-6 space-y-3">
              <li>Rendez-vous sur la page d'inscription Spybox via notre lien partenaire</li>
              <li>Choisissez votre abonnement (34,99 \u20ac/mois)</li>
              <li>Dans le champ "Code promo", saisissez <code className="rounded bg-primary/15 px-1.5 py-0.5 text-sm font-bold text-primary">GET25</code></li>
              <li>La r\u00e9duction s'applique imm\u00e9diatement sur votre premier paiement</li>
            </ol>

            <h2 className="text-2xl font-bold text-foreground pt-6">Le code GET25 est-il toujours valide ?</h2>
            <p>Oui, le code promo GET25 est actuellement valide et v\u00e9rifi\u00e9 r\u00e9guli\u00e8rement par notre \u00e9quipe. Il est sp\u00e9cifiquement li\u00e9 \u00e0 notre partenariat avec Spybox et fonctionne sur tous les types d'abonnements sans exception.</p>
            <p>Contrairement aux codes promo que vous pouvez trouver sur des sites de coupons g\u00e9n\u00e9riques, GET25 est un code partenaire officiel qui garantit une r\u00e9duction r\u00e9elle et imm\u00e9diate.</p>
          </div>
        </section>

        <CoconLinks current="/code-promo-spybox" links={[
          { href: "/prix-spybox", label: "Prix Spybox 2025" },
          { href: "/economies-spybox", label: "\u00c9conomies r\u00e9alis\u00e9es" },
          { href: "/abonnement-spybox-etapes", label: "Comment s'abonner" },
          { href: "/simulateur-economies-spybox", label: "Simulateur d'\u00e9conomies" },
          { href: "/quest-ce-que-spybox", label: "Qu'est-ce que Spybox ?" },
        ]} />
      </article>
    </>
  )
}
