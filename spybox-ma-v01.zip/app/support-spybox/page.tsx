import type { Metadata } from "next"
import { PageHeader } from "@/components/spybox/page-header"
import { CoconLinks } from "@/components/spybox/cocon-links"
import { ArticleJsonLd } from "@/components/spybox/article-json-ld"
import { ArrowRight, Mail, MessageCircle, Clock } from "lucide-react"

const SPYBOX_LINK = "https://spybox.io/?via=sign-ma"

export const metadata: Metadata = {
  title: "Support Spybox -- Aide et contact du service client",
  description: "Besoin d'aide avec Spybox ? D\u00e9couvrez les options de support : chat en direct, email, FAQ. Temps de r\u00e9ponse moyen inf\u00e9rieur \u00e0 24h.",
  alternates: { canonical: "/support-spybox" },
}

export default function SupportSpybox() {
  return (
    <>
      <ArticleJsonLd title="Support Spybox" description="Options de support et contact Spybox." slug="support-spybox" datePublished="2025-05-05" dateModified="2025-06-01" />
      <article>
        <PageHeader badge="Support" title="Support Spybox : comment obtenir de l'aide" description="L'\u00e9quipe Spybox est disponible pour r\u00e9pondre \u00e0 vos questions techniques et commerciales." />

        <section className="border-t border-border py-16">
          <div className="mx-auto max-w-4xl px-4 lg:px-8 space-y-8 text-base leading-relaxed text-muted-foreground">
            <div className="grid gap-4 sm:grid-cols-3">
              {[
                { icon: MessageCircle, title: "Chat en direct", desc: "Disponible depuis votre dashboard Spybox. R\u00e9ponse rapide pendant les heures ouvr\u00e9es." },
                { icon: Mail, title: "Email", desc: "Envoyez votre demande par email. R\u00e9ponse garantie sous 24h ouvr\u00e9es." },
                { icon: Clock, title: "FAQ", desc: "Consultez les r\u00e9ponses aux questions les plus fr\u00e9quentes dans notre section FAQ." },
              ].map((c) => (
                <div key={c.title} className="rounded-xl border border-border bg-card p-5 text-center">
                  <c.icon className="mx-auto h-8 w-8 text-primary" aria-hidden="true" />
                  <h2 className="mt-3 font-bold text-foreground">{c.title}</h2>
                  <p className="mt-2 text-sm">{c.desc}</p>
                </div>
              ))}
            </div>

            <h2 className="text-2xl font-bold text-foreground">Probl\u00e8mes courants et solutions</h2>
            <div className="space-y-4">
              {[
                { p: "Impossible de me connecter", s: "V\u00e9rifiez vos identifiants et tentez une r\u00e9initialisation de mot de passe. Si le probl\u00e8me persiste, contactez le support via le chat." },
                { p: "Mes cr\u00e9dits s'\u00e9puisent trop vite", s: "Consultez l'historique de consommation dans votre dashboard. Optimisez vos recherches en utilisant les filtres et en exportant les r\u00e9sultats en CSV." },
                { p: "Un outil ne fonctionne pas", s: "Videz le cache de votre navigateur et r\u00e9essayez. Si le probl\u00e8me persiste, signalez-le au support avec une capture d'\u00e9cran." },
                { p: "Je souhaite r\u00e9silier mon abonnement", s: "Rendez-vous dans Param\u00e8tres > Abonnement > R\u00e9silier. L'acc\u00e8s reste actif jusqu'\u00e0 la fin de la p\u00e9riode pay\u00e9e." },
              ].map((item) => (
                <div key={item.p} className="rounded-xl border border-border bg-card p-5">
                  <h3 className="font-semibold text-foreground">{item.p}</h3>
                  <p className="mt-2 text-sm">{item.s}</p>
                </div>
              ))}
            </div>

            <div className="pt-4 text-center">
              <a href={SPYBOX_LINK} target="_blank" rel="noopener noreferrer" className="inline-flex h-12 items-center gap-2 rounded-xl bg-primary px-8 font-bold text-primary-foreground transition-all hover:bg-accent hover:shadow-lg hover:shadow-primary/25">
                Acc\u00e9der \u00e0 Spybox -- Code GET25
                <ArrowRight className="h-4 w-4" aria-hidden="true" />
              </a>
            </div>
          </div>
        </section>
        <CoconLinks current="/support-spybox" links={[
          { href: "/faq-spybox", label: "FAQ Spybox" },
          { href: "/interface-spybox", label: "Interface Spybox" },
          { href: "/credits-recharges-spybox", label: "Cr\u00e9dits et recharges" },
          { href: "/abonnement-spybox-etapes", label: "Comment s'abonner" },
          { href: "/quest-ce-que-spybox", label: "Qu'est-ce que Spybox ?" },
        ]} />
      </article>
    </>
  )
}
