import type { Metadata } from "next"
import { PageHeader } from "@/components/spybox/page-header"
import { CoconLinks } from "@/components/spybox/cocon-links"
import { ArticleJsonLd } from "@/components/spybox/article-json-ld"
import { ArrowRight } from "lucide-react"

const SPYBOX_LINK = "https://spybox.io/?via=sign-ma"

export const metadata: Metadata = {
  title: "Workflow Dropshipping Spybox -- De la recherche produit \u00e0 la vente",
  description: "Workflow dropshipping complet avec Spybox : recherche produit (Minea), espionnage pub (AdSpy), cr\u00e9ation de contenu (IA), lancement de campagne.",
  alternates: { canonical: "/workflow-dropshipping-spybox" },
}

const workflow = [
  { step: "1", title: "Recherche produit", tool: "Minea / ShopHunter", desc: "Identifiez un produit \u00e0 fort potentiel en filtrant par engagement, pays cible et tendance de vente." },
  { step: "2", title: "Validation concurrentielle", tool: "AdSpy / BigSpy", desc: "V\u00e9rifiez si le produit est d\u00e9j\u00e0 publicit\u00e9. Analysez les cr\u00e9atifs, les angles marketing et la dur\u00e9e des campagnes." },
  { step: "3", title: "Cr\u00e9ation des visuels", tool: "Midjourney / DALL-E", desc: "G\u00e9n\u00e9rez des visuels produit professionnels, des mises en situation et des variantes pour vos tests A/B." },
  { step: "4", title: "R\u00e9daction des fiches", tool: "ChatGPT / Claude", desc: "R\u00e9digez des descriptions produit persuasives, des emails de relance et des scripts publicitaires." },
  { step: "5", title: "Cr\u00e9ation vid\u00e9o", tool: "Runway / HeyGen", desc: "Montez des vid\u00e9os UGC-style ou des d\u00e9mos produit avec des avatars IA pour TikTok et Instagram Reels." },
  { step: "6", title: "Lancement & optimisation", tool: "PPAds / RankerFox", desc: "Lancez vos campagnes, surveillez les performances et optimisez votre SEO pour le trafic organique." },
]

export default function WorkflowDropshippingSpybox() {
  return (
    <>
      <ArticleJsonLd title="Workflow Dropshipping Spybox" description="Workflow dropshipping complet de la recherche produit \u00e0 la vente." slug="workflow-dropshipping-spybox" datePublished="2025-04-05" dateModified="2025-06-01" />
      <article>
        <PageHeader badge="Tutoriel" title="Workflow dropshipping complet : de la recherche produit \u00e0 la vente avec Spybox" description="6 \u00e9tapes pour lancer un produit gagnant en utilisant uniquement les outils disponibles dans Spybox." />

        <section className="border-t border-border py-16">
          <div className="mx-auto max-w-4xl px-4 lg:px-8 space-y-6">
            {workflow.map((w) => (
              <div key={w.step} className="flex gap-5">
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-primary text-lg font-bold text-primary-foreground">{w.step}</div>
                <div>
                  <h2 className="text-lg font-bold text-foreground">{w.title} <span className="text-sm font-normal text-primary">({w.tool})</span></h2>
                  <p className="mt-1 text-base leading-relaxed text-muted-foreground">{w.desc}</p>
                </div>
              </div>
            ))}

            <div className="pt-8 text-center">
              <a href={SPYBOX_LINK} target="_blank" rel="noopener noreferrer" className="inline-flex h-12 items-center gap-2 rounded-xl bg-primary px-8 font-bold text-primary-foreground transition-all hover:bg-accent hover:shadow-lg hover:shadow-primary/25">
                Lancer mon workflow -- Code GET25
                <ArrowRight className="h-4 w-4" aria-hidden="true" />
              </a>
            </div>
          </div>
        </section>
        <CoconLinks current="/workflow-dropshipping-spybox" links={[
          { href: "/spybox-dropshipping", label: "Spybox pour le dropshipping" },
          { href: "/minea-spybox", label: "Minea dans Spybox" },
          { href: "/adspy-ppads-spybox", label: "AdSpy & PPAds" },
          { href: "/tuto-debutant-spybox", label: "Tutoriel d\u00e9butant" },
          { href: "/optimisation-ads-spybox", label: "Optimisation publicitaire" },
        ]} />
      </article>
    </>
  )
}
