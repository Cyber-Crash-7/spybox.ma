import type { Metadata } from "next"
import { PageHeader } from "@/components/spybox/page-header"
import { CoconLinks } from "@/components/spybox/cocon-links"
import { ArticleJsonLd } from "@/components/spybox/article-json-ld"
import { ArrowRight } from "lucide-react"

const SPYBOX_LINK = "https://spybox.io/?via=sign-ma"

export const metadata: Metadata = {
  title: "Tutoriel Spybox d\u00e9butant -- Guide de prise en main complet",
  description: "Guide d\u00e9butant Spybox : apprenez \u00e0 naviguer dans l'interface, utiliser vos premiers outils et optimiser vos cr\u00e9dits SBC. Tutoriel pas \u00e0 pas.",
  alternates: { canonical: "/tutoriel-debutant-spybox" },
}

export default function TutoDebutantSpybox() {
  return (
    <>
      <ArticleJsonLd title="Tutoriel Spybox d\u00e9butant" description="Guide de prise en main Spybox pour d\u00e9butants." slug="tuto-debutant-spybox" datePublished="2025-04-01" dateModified="2025-06-01" />
      <article>
        <PageHeader badge="Tutoriel" title="Tutoriel Spybox pour d\u00e9butants : prise en main en 10 minutes" description="Votre premier jour sur Spybox ? Ce guide pas \u00e0 pas vous montre comment tirer le maximum de la plateforme d\u00e8s votre premi\u00e8re connexion." />

        <section className="border-t border-border py-16">
          <div className="mx-auto max-w-4xl px-4 lg:px-8 space-y-6 text-base leading-relaxed text-muted-foreground">
            <h2 className="text-2xl font-bold text-foreground">1. D\u00e9couvrez le dashboard</h2>
            <p>Apr\u00e8s votre premi\u00e8re connexion, le dashboard Spybox affiche un aper\u00e7u de vos cr\u00e9dits SBC restants, un acc\u00e8s rapide aux outils r\u00e9cemment utilis\u00e9s, et une barre de recherche pour trouver n'importe quel outil en un clic.</p>

            <h2 className="text-2xl font-bold text-foreground pt-6">2. Lancez votre premi\u00e8re recherche produit</h2>
            <p>Cliquez sur Minea dans la cat\u00e9gorie "Product Research". Utilisez les filtres (pays, plateforme, date) pour trouver des produits viraux. Sauvegardez vos favoris dans votre biblioth\u00e8que personnelle pour y revenir plus tard.</p>

            <h2 className="text-2xl font-bold text-foreground pt-6">3. Espionnez une publicit\u00e9 concurrente</h2>
            <p>Ouvrez AdSpy depuis le menu "Ad Spy". Entrez un mot-cl\u00e9 li\u00e9 \u00e0 votre niche et filtrez par nombre de likes, dur\u00e9e de diffusion et plateforme (Facebook, TikTok, Instagram). Les publicit\u00e9s les plus anciennes et encore actives sont g\u00e9n\u00e9ralement les plus rentables.</p>

            <h2 className="text-2xl font-bold text-foreground pt-6">4. Analysez le SEO d'un concurrent</h2>
            <p>Acc\u00e9dez \u00e0 RankerFox et entrez l'URL d'un site concurrent. L'outil g\u00e9n\u00e8re un rapport complet avec les mots-cl\u00e9s positionn\u00e9s, le trafic estim\u00e9 et les backlinks. Utilisez ces donn\u00e9es pour construire votre propre strat\u00e9gie SEO.</p>

            <h2 className="text-2xl font-bold text-foreground pt-6">5. G\u00e9rez vos cr\u00e9dits intelligemment</h2>
            <p>Consultez votre solde de cr\u00e9dits SBC r\u00e9guli\u00e8rement depuis le dashboard. Privil\u00e9giez les recherches cibl\u00e9es (avec filtres) plut\u00f4t que les recherches larges pour consommer moins de cr\u00e9dits par session.</p>

            <div className="pt-6 text-center">
              <a href={SPYBOX_LINK} target="_blank" rel="noopener noreferrer" className="inline-flex h-12 items-center gap-2 rounded-xl bg-primary px-8 font-bold text-primary-foreground transition-all hover:bg-accent hover:shadow-lg hover:shadow-primary/25">
                Cr\u00e9er mon compte -- Code GET25
                <ArrowRight className="h-4 w-4" aria-hidden="true" />
              </a>
            </div>
          </div>
        </section>
        <CoconLinks current="/tuto-debutant-spybox" links={[
          { href: "/workflow-dropshipping-spybox", label: "Workflow Dropshipping" },
          { href: "/workflow-seo-spybox", label: "Workflow SEO" },
          { href: "/interface-spybox", label: "Interface Spybox" },
          { href: "/credits-sbc-spybox", label: "Cr\u00e9dits SBC" },
          { href: "/abonnement-spybox-etapes", label: "Comment s'abonner" },
        ]} />
      </article>
    </>
  )
}
