import type { Metadata } from "next"
import { PageHeader } from "@/components/spybox/page-header"
import { CoconLinks } from "@/components/spybox/cocon-links"
import { ArticleJsonLd } from "@/components/spybox/article-json-ld"
export const metadata: Metadata = { title: "Outils IA Vidéo dans Spybox : Runway, Sora & Montage Automatique (2025)", description: "Créez des vidéos publicitaires et du contenu vidéo avec les outils IA de Spybox : Runway, Sora, montage automatique et génération de clips pour TikTok et Reels.", alternates: { canonical: "/spybox-ia-video" } }
export default function Page() {
  return (
    <>
      <ArticleJsonLd title="Outils IA Vidéo dans Spybox : Runway, Sora & Montage Automatique" description="Créez des vidéos IA avec Runway et Sora via Spybox." slug="spybox-ia-video" />
      <PageHeader h1="Outils IA vidéo dans Spybox : Runway, Sora et montage automatique" breadcrumb={[{ label: "Accueil", href: "/" }, { label: "Outils IA" }, { label: "IA Vidéo" }]} subtitle="Produisez des clips publicitaires, des démos produit et du contenu vidéo sans caméra ni monteur." />
      <article className="mx-auto max-w-4xl px-4 py-12 lg:px-8 lg:py-16">
        <div className="space-y-6 text-base leading-relaxed text-muted-foreground">
          <h2 className="text-2xl font-bold text-foreground">La vidéo IA : du texte au clip en quelques minutes</h2>
          <p>Les outils IA vidéo permettent de générer des clips à partir de descriptions texte, d'images ou de scripts. Runway transforme une image en vidéo animée, génère des transitions fluides et permet un montage assisté par IA. C'est la solution idéale pour produire des publicités vidéo sans tournage physique ni compétences en montage.</p>
          <h2 className="text-2xl font-bold text-foreground">Runway dans Spybox</h2>
          <p>Runway offre la génération vidéo à partir de prompts texte (text-to-video), l'animation d'images fixes (image-to-video), la suppression automatique d'arrière-plan vidéo, et le montage intelligent avec transitions. Dans Spybox, ces fonctionnalités sont accessibles via les crédits SBC sans abonnement Runway séparé.</p>
          <h2 className="text-2xl font-bold text-foreground">Produire des publicités vidéo sans équipe</h2>
          <p>Le workflow vidéo dans Spybox : écrivez le script avec ChatGPT, générez les visuels clés avec Midjourney, animez-les avec Runway, ajoutez une voix-off avec ElevenLabs. En 2 à 3 heures, vous produisez une publicité vidéo professionnelle qui aurait coûté 1 000 à 5 000 € en production classique.</p>
          <h2 className="text-2xl font-bold text-foreground">Formats optimisés pour chaque plateforme</h2>
          <p>Runway permet d'exporter aux formats 9:16 (TikTok, Reels), 1:1 (Feed Instagram) et 16:9 (YouTube). Adaptez chaque créative au format natif de la plateforme pour maximiser les performances. Les créatives verticales natives performent 40 % mieux que les adaptations horizontales recadrées.</p>
        </div>
        <CoconLinks title="Création de contenu IA" links={[
          { label: "IA Images (Midjourney)", href: "/spybox-ia-images" },
          { label: "IA Texte (ChatGPT)", href: "/spybox-ia-texte" },
          { label: "Avatars IA", href: "/spybox-ia-avatars" },
          { label: "Créatives UGC", href: "/creas-ugc-spybox" },
          { label: "TikTok Shop", href: "/tiktok-shop-spybox" },
          { label: "Meilleures créatives", href: "/meilleures-creas-spybox" },
        ]} />
      </article>
    </>
  )
}
