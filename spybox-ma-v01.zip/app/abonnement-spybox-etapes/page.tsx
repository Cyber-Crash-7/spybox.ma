import type { Metadata } from "next"
import { PageHeader } from "@/components/spybox/page-header"
import { CoconLinks } from "@/components/spybox/cocon-links"
import { ArticleJsonLd } from "@/components/spybox/article-json-ld"
import { ArrowRight } from "lucide-react"

const SPYBOX_LINK = "https://spybox.io/?via=sign-ma"

export const metadata: Metadata = {
  title: "Comment s'abonner \u00e0 Spybox -- Guide \u00e9tape par \u00e9tape",
  description: "Guide complet pour s'abonner \u00e0 Spybox en 5 minutes. Mensuel 34,99 \u20ac/mois ou annuel 349,99 \u20ac/an. Code promo GET25.",
  alternates: { canonical: "/abonnement-spybox-etapes" },
}

const steps = [
  { step: "1", title: "Cr\u00e9ez votre compte", desc: "Rendez-vous sur Spybox via notre lien partenaire et remplissez le formulaire d'inscription avec votre email et un mot de passe." },
  { step: "2", title: "Choisissez votre formule", desc: "S\u00e9lectionnez l'abonnement mensuel \u00e0 34,99 \u20ac/mois (sans engagement) ou annuel \u00e0 349,99 \u20ac/an (2 mois offerts, soit 29,17 \u20ac/mois)." },
  { step: "3", title: "Appliquez le code GET25", desc: "Dans le champ code promo, saisissez GET25 pour b\u00e9n\u00e9ficier de votre r\u00e9duction exclusive (valable sur les deux formules)." },
  { step: "4", title: "Proc\u00e9dez au paiement", desc: "Paiement s\u00e9curis\u00e9 par carte bancaire ou PayPal. La transaction est chiffr\u00e9e et vos donn\u00e9es sont prot\u00e9g\u00e9es." },
  { step: "5", title: "Acc\u00e9dez aux 90+ outils", desc: "Votre compte est activ\u00e9 instantan\u00e9ment. Connectez-vous au dashboard et commencez \u00e0 utiliser tous les outils." },
]

export default function AbonnementSpyboxEtapes() {
  return (
    <>
      <ArticleJsonLd title="Comment s'abonner \u00e0 Spybox" description="Guide \u00e9tape par \u00e9tape pour s'abonner \u00e0 Spybox (mensuel ou annuel)." slug="abonnement-spybox-etapes" datePublished="2025-03-15" dateModified="2025-06-01" />
      <article>
        <PageHeader badge="Guide" title="Comment s'abonner \u00e0 Spybox en 5 \u00e9tapes simples" description="De la cr\u00e9ation de compte \u00e0 l'acc\u00e8s aux 90+ outils. Mensuel ou annuel, tout se fait en moins de 5 minutes." />

        <section className="border-t border-border py-16">
          <div className="mx-auto max-w-4xl px-4 lg:px-8 space-y-6">
            {steps.map((s) => (
              <div key={s.step} className="flex gap-5">
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-primary text-lg font-bold text-primary-foreground">{s.step}</div>
                <div>
                  <h2 className="text-lg font-bold text-foreground">{s.title}</h2>
                  <p className="mt-1 text-base leading-relaxed text-muted-foreground">{s.desc}</p>
                </div>
              </div>
            ))}

            {/* Comparatif rapide */}
            <div className="mt-8 grid gap-4 sm:grid-cols-2">
              <div className="rounded-xl border border-border bg-card p-5 text-center">
                <p className="text-sm font-medium uppercase tracking-wider text-primary">Mensuel</p>
                <p className="mt-2 text-3xl font-extrabold text-foreground">34,99 &euro;<span className="text-base font-medium text-muted-foreground">/mois</span></p>
                <p className="mt-1 text-sm text-muted-foreground">Sans engagement</p>
              </div>
              <div className="rounded-xl border border-primary/30 bg-primary/5 p-5 text-center">
                <p className="text-sm font-medium uppercase tracking-wider text-primary">Annuel</p>
                <p className="mt-2 text-3xl font-extrabold text-foreground">249,99 &euro;<span className="text-base font-medium text-muted-foreground">/an</span></p>
                <p className="mt-1 text-sm text-primary font-semibold">20,83 &euro;/mois -- ~5 mois offerts</p>
              </div>
            </div>

            <div className="pt-8 text-center">
              <a href={SPYBOX_LINK} target="_blank" rel="noopener noreferrer" className="inline-flex h-12 items-center gap-2 rounded-xl bg-primary px-8 font-bold text-primary-foreground transition-all hover:bg-accent hover:shadow-lg hover:shadow-primary/25">
                Commencer maintenant -- Code GET25
                <ArrowRight className="h-4 w-4" aria-hidden="true" />
              </a>
            </div>
          </div>
        </section>
        <CoconLinks current="/abonnement-spybox-etapes" links={[
          { href: "/prix-spybox", label: "Prix Spybox" },
          { href: "/code-promo-get25", label: "Code promo GET25" },
          { href: "/interface-dashboard-spybox", label: "Interface Spybox" },
          { href: "/credits-sbc-spybox", label: "Cr\u00e9dits SBC" },
          { href: "/faq-spybox", label: "FAQ Spybox" },
        ]} />
      </article>
    </>
  )
}
