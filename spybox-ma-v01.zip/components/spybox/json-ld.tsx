const SPYBOX_LINK = "https://spybox.io/?via=sign-ma"

const faqs = [
  {
    q: "Qu'est-ce que Spybox exactement ?",
    a: "Spybox est une plateforme qui mutualise l'accès à plus de 90 outils premium (SEO, e-commerce, publicité, IA) pour un seul abonnement à 34,99 €/mois.",
  },
  {
    q: "Comment fonctionnent les crédits SBC ?",
    a: "Chaque outil consomme des crédits SBC. Votre abonnement inclut 100 000 crédits SBC par mois, renouvelés automatiquement.",
  },
  {
    q: "Le code promo GET25 est-il valide ?",
    a: "Oui, le code promo GET25 est actuellement actif. Appliquez-le lors de votre inscription pour bénéficier d'une réduction.",
  },
  {
    q: "Combien d'outils sont inclus ?",
    a: "Spybox donne accès à plus de 90 outils premium : Product Research, Ad Spy, SEO et Intelligence Artificielle.",
  },
  {
    q: "Puis-je annuler à tout moment ?",
    a: "Oui, l'abonnement est sans engagement. Vous pouvez résilier quand vous le souhaitez.",
  },
  {
    q: "L'accès est-il instantané ?",
    a: "Oui, dès la validation du paiement, vous accédez immédiatement à tous les outils.",
  },
]

export function HomeJsonLd() {
  const productSchema = {
    "@context": "https://schema.org",
    "@type": "Product",
    name: "Spybox – Plateforme 90+ Outils Premium",
    description:
      "Accès mutualisé à 90+ outils premium (e-commerce, SEO, IA, AdSpy) via un seul abonnement mensuel avec 100 000 crédits SBC.",
    brand: {
      "@type": "Brand",
      name: "Spybox",
    },
    url: SPYBOX_LINK,
    image: "https://spybox.io/og-image.png",
    offers: [
      {
        "@type": "Offer",
        name: "Abonnement mensuel",
        price: "34.99",
        priceCurrency: "EUR",
        url: SPYBOX_LINK,
        availability: "https://schema.org/InStock",
        priceValidUntil: "2026-12-31",
      },
      {
        "@type": "Offer",
        name: "Abonnement annuel",
        price: "249.99",
        priceCurrency: "EUR",
        url: SPYBOX_LINK,
        availability: "https://schema.org/InStock",
        priceValidUntil: "2026-12-31",
      },
    ],
    aggregateRating: {
      "@type": "AggregateRating",
      ratingValue: "4.4",
      reviewCount: "1250",
      bestRating: "5",
      worstRating: "1",
    },
  }

  const articleSchema = {
    "@context": "https://schema.org",
    "@type": "Article",
    headline:
      "Spybox : La Plateforme Officielle de 90+ Outils Premium Mutualisés",
    description:
      "Accédez à la plateforme Spybox officielle : 90+ outils premium mutualisés (e-commerce, SEO, IA, AdSpy). Abonnement 34,99 €/mois avec 100 000 crédits SBC.",
    url: "https://spybox.ma",
    author: {
      "@type": "Organization",
      name: "Spybox",
    },
    publisher: {
      "@type": "Organization",
      name: "Spybox",
    },
    datePublished: "2026-01-15",
    dateModified: "2026-02-22",
    mainEntityOfPage: "https://spybox.ma",
  }

  const faqSchema = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: faqs.map((f) => ({
      "@type": "Question",
      name: f.q,
      acceptedAnswer: {
        "@type": "Answer",
        text: f.a,
      },
    })),
  }

  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(productSchema) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(articleSchema) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(faqSchema) }}
      />
    </>
  )
}
