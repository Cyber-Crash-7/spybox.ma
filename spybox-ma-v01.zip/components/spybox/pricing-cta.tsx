"use client"

import { useState } from "react"
import { ArrowRight, Check } from "lucide-react"

const SPYBOX_LINK = "https://spybox.io/?via=sign-ma"

const included = [
  "90+ outils premium inclus",
  "100 000 crédits SBC / mois",
  "Product Research (Minea, ShopHunter...)",
  "Ad Spy (AdSpy, PPAds, BigSpy...)",
  "SEO (RankerFox, Semrush, Ahrefs...)",
  "IA (ChatGPT, Midjourney, Claude...)",
  "Dashboard centralisé",
  "Sans engagement -- annulation libre",
]

export function PricingCta() {
  const [tab, setTab] = useState<"monthly" | "annual">("monthly")

  return (
    <section className="border-t border-border bg-card py-20 lg:py-28" id="prix">
      <div className="mx-auto max-w-5xl px-4 lg:px-8">
        <div className="mx-auto mb-14 max-w-2xl text-center">
          <h2 className="text-balance text-3xl font-bold tracking-tight text-foreground md:text-4xl">
            Un prix unique pour tout accéder
          </h2>
          <p className="mt-4 text-lg leading-relaxed text-muted-foreground">
            Arrêtez de multiplier les abonnements. Spybox centralise 90+ outils pour un seul tarif.
          </p>

          {/* Toggle */}
          <div className="mx-auto mt-8 inline-flex rounded-xl border border-border bg-secondary p-1">
            <button
              type="button"
              onClick={() => setTab("monthly")}
              className={`rounded-lg px-6 py-2.5 text-sm font-medium transition-all ${tab === "monthly" ? "bg-background text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"}`}
            >
              Mensuel
            </button>
            <button
              type="button"
              onClick={() => setTab("annual")}
              className={`rounded-lg px-6 py-2.5 text-sm font-medium transition-all ${tab === "annual" ? "bg-background text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"}`}
            >
              Annuel
              <span className="ml-2 rounded-full bg-primary/15 px-2 py-0.5 text-xs font-bold text-primary">-40%</span>
            </button>
          </div>
        </div>

        <div className="mx-auto grid max-w-4xl gap-6 lg:grid-cols-2">
          {/* Mensuel */}
          <div className={`overflow-hidden rounded-2xl border bg-background transition-all ${tab === "monthly" ? "border-primary/40 shadow-xl shadow-primary/5" : "border-border opacity-80"}`}>
            <div className="border-b border-border bg-primary/5 px-8 py-6 text-center">
              <p className="text-sm font-medium uppercase tracking-wider text-primary">Mensuel</p>
              <div className="mt-3 flex items-baseline justify-center gap-1">
                <span className="text-5xl font-extrabold tracking-tight text-foreground">34,99</span>
                <span className="text-xl font-medium text-muted-foreground">€/mois</span>
              </div>
              <p className="mt-2 text-sm text-muted-foreground">Sans engagement, résiliable à tout moment</p>
            </div>
            <div className="px-8 py-8">
              <ul className="space-y-3" role="list">
                {included.map((item) => (
                  <li key={item} className="flex items-start gap-3">
                    <Check className="mt-0.5 h-5 w-5 shrink-0 text-primary" aria-hidden="true" />
                    <span className="text-sm text-foreground">{item}</span>
                  </li>
                ))}
              </ul>
              <a
                href={SPYBOX_LINK}
                target="_blank"
                rel="noopener noreferrer"
                className="group mt-8 flex h-12 w-full items-center justify-center gap-2 rounded-xl bg-primary text-base font-bold text-primary-foreground transition-all hover:bg-accent hover:shadow-lg hover:shadow-primary/25"
              >
                S'inscrire -- 34,99 €/mois
                <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" aria-hidden="true" />
              </a>
            </div>
          </div>

          {/* Annuel */}
          <div className={`relative overflow-hidden rounded-2xl border bg-background transition-all ${tab === "annual" ? "border-primary/40 shadow-xl shadow-primary/5" : "border-border opacity-80"}`}>
            <div className="absolute right-4 top-4 rounded-full bg-primary px-3 py-1 text-xs font-bold text-primary-foreground">
              Offre annuelle
            </div>
            <div className="border-b border-border bg-primary/5 px-8 py-6 text-center">
              <p className="text-sm font-medium uppercase tracking-wider text-primary">Annuel</p>
              <div className="mt-3 flex items-baseline justify-center gap-1">
                <span className="text-5xl font-extrabold tracking-tight text-foreground">249,99</span>
                <span className="text-xl font-medium text-muted-foreground">€/an</span>
              </div>
              <p className="mt-2 text-sm text-muted-foreground">
                Soit <strong className="text-primary">20,83 €/mois</strong> au lieu de 34,99 €
              </p>
            </div>
            <div className="px-8 py-8">
              <ul className="space-y-3" role="list">
                {included.map((item) => (
                  <li key={item} className="flex items-start gap-3">
                    <Check className="mt-0.5 h-5 w-5 shrink-0 text-primary" aria-hidden="true" />
                    <span className="text-sm text-foreground">{item}</span>
                  </li>
                ))}
                <li className="flex items-start gap-3">
                  <Check className="mt-0.5 h-5 w-5 shrink-0 text-primary" aria-hidden="true" />
                  <span className="text-sm font-semibold text-primary">Économie de 169,89 € par an</span>
                </li>
              </ul>
              <a
                href={SPYBOX_LINK}
                target="_blank"
                rel="noopener noreferrer"
                className="group mt-8 flex h-12 w-full items-center justify-center gap-2 rounded-xl bg-primary text-base font-bold text-primary-foreground transition-all hover:bg-accent hover:shadow-lg hover:shadow-primary/25"
              >
                S'inscrire -- 249,99 €/an
                <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" aria-hidden="true" />
              </a>
            </div>
          </div>
        </div>

        {/* Code promo */}
        <div className="mt-8 flex items-center justify-center gap-2 text-sm text-muted-foreground">
          <span>Appliquez le code</span>
          <code className="rounded bg-primary/15 px-2 py-0.5 font-bold text-primary">GET25</code>
          <span>lors de l'inscription (mensuel ou annuel)</span>
        </div>
      </div>
    </section>
  )
}
