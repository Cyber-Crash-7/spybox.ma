interface ArticleJsonLdProps {
  title: string
  description: string
  slug: string
  datePublished?: string
  dateModified?: string
  faq?: { q: string; a: string }[]
}

export function ArticleJsonLd({
  title,
  description,
  slug,
  datePublished = "2025-01-15",
  dateModified = "2025-06-01",
  faq,
}: ArticleJsonLdProps) {
  const article = {
    "@context": "https://schema.org",
    "@type": "Article",
    headline: title,
    description,
    url: `https://spybox.ma/${slug}`,
    datePublished,
    dateModified,
    author: { "@type": "Organization", name: "Spybox" },
    publisher: {
      "@type": "Organization",
      name: "Spybox",
      url: "https://spybox.ma",
    },
    mainEntityOfPage: {
      "@type": "WebPage",
      "@id": `https://spybox.ma/${slug}`,
    },
  }

  const breadcrumb = {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: [
      { "@type": "ListItem", position: 1, name: "Accueil", item: "https://spybox.ma" },
      { "@type": "ListItem", position: 2, name: title, item: `https://spybox.ma/${slug}` },
    ],
  }

  const faqSchema = faq
    ? {
        "@context": "https://schema.org",
        "@type": "FAQPage",
        mainEntity: faq.map((f) => ({
          "@type": "Question",
          name: f.q,
          acceptedAnswer: { "@type": "Answer", text: f.a },
        })),
      }
    : null

  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(article) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumb) }}
      />
      {faqSchema && (
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(faqSchema) }}
        />
      )}
    </>
  )
}
