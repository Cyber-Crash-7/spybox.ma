import { ArrowRight } from "lucide-react"

const SPYBOX_LINK = "https://spybox.io/?via=sign-ma"

export function PromoBanner() {
  return (
    <div className="relative z-50 w-full bg-primary py-2">
      <div className="mx-auto flex max-w-7xl items-center justify-center gap-3 px-4 text-sm font-medium text-primary-foreground">
        <span className="hidden sm:inline">Offre exclusive :</span>
        <span>
          Code promo{" "}
          <code className="rounded bg-primary-foreground/15 px-1.5 py-0.5 font-bold">
            GET25
          </code>
        </span>
        <span className="hidden md:inline">
          sur votre abonnement Spybox
        </span>
        <a
          href={SPYBOX_LINK}
          target="_blank"
          rel="noopener noreferrer"
          className="group inline-flex items-center gap-1 rounded-full bg-primary-foreground/15 px-3 py-0.5 text-xs font-semibold transition-colors hover:bg-primary-foreground/25"
        >
          En profiter
          <ArrowRight className="h-3 w-3 transition-transform group-hover:translate-x-0.5" aria-hidden="true" />
        </a>
      </div>
    </div>
  )
}
