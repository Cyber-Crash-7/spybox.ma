"use client"

import { useState } from "react"
import { ChevronDown } from "lucide-react"

const faqs = [
  {
    q: "Qu'est-ce que Spybox exactement ?",
    a: "Spybox est une plateforme qui mutualise l'accès à plus de 90 outils premium (SEO, e-commerce, publicité, IA) pour un seul abonnement à 34,99 €/mois. Vous accédez à des outils comme Minea, AdSpy, Semrush, RankerFox, ChatGPT et bien d'autres via un dashboard centralisé.",
  },
  {
    q: "Comment fonctionnent les crédits SBC ?",
    a: "Chaque outil consomme un nombre de crédits SBC par utilisation. Votre abonnement inclut 100\u00a0000 crédits SBC par mois, ce qui couvre un usage professionnel intensif. Les crédits se renouvellent automatiquement chaque mois.",
  },
  {
    q: "Le code promo GET25 est-il toujours valide ?",
    a: "Oui, le code promo GET25 est actuellement actif. Appliquez-le lors de votre inscription sur spybox.io pour bénéficier d'une réduction immédiate sur votre abonnement.",
  },
  {
    q: "Puis-je annuler mon abonnement à tout moment ?",
    a: "Absolument. L'abonnement Spybox est sans engagement. Vous pouvez résilier à tout moment depuis votre espace client, sans frais supplémentaires.",
  },
  {
    q: "Combien d'outils sont inclus dans Spybox ?",
    a: "Spybox donne accès à plus de 90 outils premium répartis en quatre catégories : Product Research, Ad Spy, SEO et Intelligence Artificielle. De nouveaux outils sont ajoutés chaque mois.",
  },
  {
    q: "L'accès est-il instantané après inscription ?",
    a: "Oui. Dès la validation de votre paiement, vous accédez immédiatement à l'ensemble des outils via le dashboard Spybox. Aucune installation n'est requise.",
  },
]

export function FaqHome() {
  const [openIndex, setOpenIndex] = useState<number | null>(null)

  return (
    <section className="border-t border-border py-20 lg:py-28" id="faq">
      <div className="mx-auto max-w-3xl px-4 lg:px-8">
        <h2 className="mb-12 text-center text-3xl font-bold tracking-tight text-foreground md:text-4xl">
          Questions fréquentes
        </h2>
        <div className="space-y-3">
          {faqs.map((faq, i) => (
            <div
              key={i}
              className="rounded-xl border border-border bg-card transition-colors hover:border-primary/20"
            >
              <button
                type="button"
                className="flex w-full items-center justify-between px-6 py-4 text-left"
                onClick={() => setOpenIndex(openIndex === i ? null : i)}
                aria-expanded={openIndex === i}
              >
                <span className="pr-4 text-sm font-semibold text-foreground">{faq.q}</span>
                <ChevronDown
                  className={`h-5 w-5 shrink-0 text-muted-foreground transition-transform ${
                    openIndex === i ? "rotate-180" : ""
                  }`}
                  aria-hidden="true"
                />
              </button>
              {openIndex === i && (
                <div className="border-t border-border px-6 py-4">
                  <p className="text-sm leading-relaxed text-muted-foreground">{faq.a}</p>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
