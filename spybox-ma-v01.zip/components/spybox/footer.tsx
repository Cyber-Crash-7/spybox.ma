import Link from "next/link"

const SPYBOX_LINK = "https://spybox.io/?via=sign-ma"

const footerLinks = {
  Plateforme: [
    { label: "Qu'est-ce que Spybox", href: "/quest-ce-que-spybox" },
    { label: "Fonctionnement", href: "/fonctionnement-spybox" },
    { label: "Interface & Dashboard", href: "/interface-dashboard-spybox" },
    { label: "Prix", href: "/prix-spybox" },
    { label: "Code promo GET25", href: "/code-promo-get25" },
  ],
  Outils: [
    { label: "Minea", href: "/minea-spybox" },
    { label: "AdSpy & PPAds", href: "/adspy-ppads-spybox" },
    { label: "RankerFox", href: "/rankerfox-spybox" },
    { label: "Outils IA", href: "/spybox-ia-images" },
    { label: "Tous les outils", href: "/quest-ce-que-spybox" },
  ],
  Ressources: [
    { label: "Tutoriel débutant", href: "/tutoriel-debutant-spybox" },
    { label: "FAQ", href: "/faq-spybox" },
    { label: "Support", href: "/support-spybox" },
    { label: "Blog Spybox", href: "https://spybox-avis.com/", external: true },
  ],
  Partenaires: [
    { label: "Spybox Code Promo", href: "https://spybox-code-promo.fr/", external: true },
    { label: "ToolsBox SEO", href: "https://toolsboxseo.com/spybox-avis-outils-seo-ecommerce-code-promo/", external: true },
    { label: "RankerFox Alternative", href: "https://rankerfox-alternative.com/outils-spybox", external: true },
  ],
}

export function Footer() {
  return (
    <footer className="border-t border-border bg-card">
      <div className="mx-auto max-w-7xl px-4 py-16 lg:px-8">
        <div className="grid gap-10 sm:grid-cols-2 lg:grid-cols-5">
          {/* Brand */}
          <div className="lg:col-span-1">
            <Link href="/" className="flex items-center gap-2" aria-label="Spybox - Accueil">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                  <path d="M15.5 14h-.79l-.28-.27A6.471 6.471 0 0016 9.5 6.5 6.5 0 109.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z" fill="currentColor" className="text-primary-foreground"/>
                </svg>
              </div>
              <span className="text-lg font-bold text-foreground">Spybox</span>
            </Link>
            <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
              La plateforme officielle d'accès mutualisé à 90+ outils premium.
            </p>
            <a
              href={SPYBOX_LINK}
              target="_blank"
              rel="noopener noreferrer"
              className="mt-4 inline-flex h-9 items-center rounded-lg bg-primary px-4 text-sm font-semibold text-primary-foreground transition-colors hover:bg-accent"
            >
              Connexion
            </a>
          </div>

          {/* Links */}
          {Object.entries(footerLinks).map(([title, links]) => (
            <div key={title}>
              <h3 className="mb-4 text-sm font-semibold text-foreground">{title}</h3>
              <ul className="space-y-2.5" role="list">
                {links.map((link) => (
                  <li key={link.label}>
                    {"external" in link && link.external ? (
                      <a
                        href={link.href}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-sm text-muted-foreground transition-colors hover:text-primary"
                      >
                        {link.label}
                      </a>
                    ) : (
                      <Link
                        href={link.href}
                        className="text-sm text-muted-foreground transition-colors hover:text-primary"
                      >
                        {link.label}
                      </Link>
                    )}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="mt-12 flex flex-col items-center justify-between gap-4 border-t border-border pt-8 sm:flex-row">
          <p className="text-xs text-muted-foreground">
            &copy; 2026 Spybox. Tous droits réservés. Code promo : GET25
          </p>
          <p className="text-xs text-muted-foreground">
            Site affilié &ndash; nous pouvons percevoir une commission sur les inscriptions.
          </p>
        </div>
      </div>
    </footer>
  )
}
