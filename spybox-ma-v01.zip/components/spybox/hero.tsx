import { ArrowRight, Zap, CreditCard, Shield } from "lucide-react"

const SPYBOX_LINK = "https://spybox.io/?via=sign-ma"

export function Hero() {
  return (
    <section className="relative overflow-hidden pb-20 pt-16 lg:pb-28 lg:pt-24">
      {/* Subtle grid background */}
      <div
        className="pointer-events-none absolute inset-0 opacity-[0.03]"
        style={{
          backgroundImage:
            "linear-gradient(rgba(255,255,255,.1) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,.1) 1px, transparent 1px)",
          backgroundSize: "64px 64px",
        }}
        aria-hidden="true"
      />
      <div className="relative mx-auto max-w-7xl px-4 lg:px-8">
        <div className="mx-auto max-w-4xl text-center">
          {/* Badge */}
          <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-4 py-1.5">
            <Zap className="h-4 w-4 text-primary" aria-hidden="true" />
            <span className="text-sm font-medium text-primary">
              90+ outils premium – dès 20,83 €/mois (annuel)
            </span>
          </div>

          {/* H1 */}
          <h1 className="text-balance text-4xl font-extrabold leading-tight tracking-tight text-foreground md:text-5xl lg:text-6xl">
            Spybox : La Plateforme Officielle de 90+ Outils Premium Mutualisés
          </h1>

          {/* Subtitle */}
          <p className="mx-auto mt-6 max-w-2xl text-pretty text-lg leading-relaxed text-muted-foreground lg:text-xl">
            Accédez à Minea, AdSpy, RankerFox, Semrush, ChatGPT, Midjourney et 80+ outils depuis un seul abonnement. 100&nbsp;000 crédits SBC inclus chaque mois.
          </p>

          {/* CTA row */}
          <div className="mt-10 flex flex-col items-center gap-4 sm:flex-row sm:justify-center">
            <a
              href={SPYBOX_LINK}
              target="_blank"
              rel="noopener noreferrer"
              className="group inline-flex h-12 items-center gap-2 rounded-xl bg-primary px-8 text-base font-bold text-primary-foreground transition-all hover:bg-accent hover:shadow-lg hover:shadow-primary/25"
            >
              Accéder à Spybox
              <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" aria-hidden="true" />
            </a>
            <div className="flex items-center gap-2 rounded-xl border border-border bg-secondary px-5 py-3">
              <span className="text-sm text-muted-foreground">Code promo :</span>
              <code className="rounded bg-primary/15 px-2 py-0.5 text-sm font-bold text-primary">
                GET25
              </code>
            </div>
          </div>

          {/* Trust badges */}
          <div className="mt-12 flex flex-wrap items-center justify-center gap-8">
            <div className="flex items-center gap-2 text-muted-foreground">
              <Shield className="h-5 w-5 text-primary" aria-hidden="true" />
              <span className="text-sm font-medium">Paiement sécurisé</span>
            </div>
            <div className="flex items-center gap-2 text-muted-foreground">
              <CreditCard className="h-5 w-5 text-primary" aria-hidden="true" />
              <span className="text-sm font-medium">34,99 €/mois ou 249,99 €/an</span>
            </div>
            <div className="flex items-center gap-2 text-muted-foreground">
              <Zap className="h-5 w-5 text-primary" aria-hidden="true" />
              <span className="text-sm font-medium">100&nbsp;000 crédits SBC</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
