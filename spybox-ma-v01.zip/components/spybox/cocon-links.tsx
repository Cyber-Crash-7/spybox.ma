import Link from "next/link"
import { ArrowRight } from "lucide-react"

interface CoconLink {
  label: string
  href: string
}

interface CoconLinksProps {
  title?: string
  links: CoconLink[]
}

export function CoconLinks({ title = "Articles connexes", links }: CoconLinksProps) {
  return (
    <nav aria-label="Maillage interne" className="mt-12 border-t border-border pt-10">
      <h2 className="mb-6 text-xl font-bold text-foreground">{title}</h2>
      <div className="grid gap-3 sm:grid-cols-2">
        {links.map((link) => (
          <Link
            key={link.href}
            href={link.href}
            className="group flex items-center justify-between rounded-xl border border-border bg-card px-5 py-4 transition-all hover:border-primary/30 hover:bg-secondary"
          >
            <span className="text-sm font-medium text-foreground">{link.label}</span>
            <ArrowRight className="h-4 w-4 shrink-0 text-muted-foreground transition-transform group-hover:translate-x-1 group-hover:text-primary" aria-hidden="true" />
          </Link>
        ))}
      </div>
    </nav>
  )
}
