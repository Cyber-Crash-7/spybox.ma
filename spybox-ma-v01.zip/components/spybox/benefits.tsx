import { DollarSign, Gauge, RefreshCw, Lock, BarChart3, Headphones } from "lucide-react"

const benefits = [
  {
    icon: DollarSign,
    title: "Économisez plus de 8\u00a0000 €/an",
    description:
      "Un seul abonnement à 34,99 €/mois remplace des dizaines d'abonnements individuels. ROI immédiat dès le premier mois.",
  },
  {
    icon: Gauge,
    title: "100\u00a0000 crédits SBC/mois",
    description:
      "Chaque outil consomme des crédits SBC. Avec 100\u00a0000 crédits mensuels, vous couvrez un usage professionnel intensif.",
  },
  {
    icon: RefreshCw,
    title: "Mise à jour permanente",
    description:
      "De nouveaux outils sont ajoutés chaque mois sans surcoût. Votre stack reste toujours à la pointe du marché.",
  },
  {
    icon: Lock,
    title: "Accès sécurisé et instantané",
    description:
      "Connexion en un clic à chaque outil via le dashboard centralisé. Aucune installation requise.",
  },
  {
    icon: BarChart3,
    title: "Dashboard unifié",
    description:
      "Pilotez tous vos outils depuis une interface unique : product research, ad spy, SEO, IA au même endroit.",
  },
  {
    icon: Headphones,
    title: "Support réactif",
    description:
      "Équipe de support disponible pour vous accompagner dans la configuration et l'utilisation quotidienne de Spybox.",
  },
]

export function Benefits() {
  return (
    <section className="border-t border-border bg-card py-20 lg:py-28">
      <div className="mx-auto max-w-7xl px-4 lg:px-8">
        <div className="mx-auto mb-14 max-w-2xl text-center">
          <h2 className="text-balance text-3xl font-bold tracking-tight text-foreground md:text-4xl">
            {"Pourquoi 12\u00a0000+ professionnels choisissent Spybox"}
          </h2>
          <p className="mt-4 text-lg leading-relaxed text-muted-foreground">
            {"La plateforme tout-en-un qui centralise vos outils e-commerce, SEO et IA à un prix unique."}
          </p>
        </div>

        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {benefits.map((b) => (
            <div
              key={b.title}
              className="group rounded-2xl border border-border bg-background p-6 transition-all hover:border-primary/30 hover:shadow-lg hover:shadow-primary/5"
            >
              <div className="mb-4 flex h-11 w-11 items-center justify-center rounded-xl bg-primary/10 text-primary transition-colors group-hover:bg-primary group-hover:text-primary-foreground">
                <b.icon className="h-5 w-5" aria-hidden="true" />
              </div>
              <h3 className="mb-2 text-lg font-semibold text-foreground">{b.title}</h3>
              <p className="text-sm leading-relaxed text-muted-foreground">{b.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
