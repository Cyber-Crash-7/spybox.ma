import Link from "next/link"
import { ChevronRight } from "lucide-react"

interface PageHeaderProps {
  h1: string
  breadcrumb: { label: string; href?: string }[]
  subtitle?: string
}

export function PageHeader({ h1, breadcrumb, subtitle }: PageHeaderProps) {
  return (
    <section className="border-b border-border bg-card py-12 lg:py-16">
      <div className="mx-auto max-w-4xl px-4 lg:px-8">
        <nav aria-label="Fil d'Ariane" className="mb-6 flex items-center gap-1 text-sm text-muted-foreground">
          {breadcrumb.map((item, i) => (
            <span key={i} className="flex items-center gap-1">
              {i > 0 && <ChevronRight className="h-3 w-3" aria-hidden="true" />}
              {item.href ? (
                <Link href={item.href} className="hover:text-primary transition-colors">{item.label}</Link>
              ) : (
                <span className="text-foreground">{item.label}</span>
              )}
            </span>
          ))}
        </nav>
        <h1 className="text-3xl font-extrabold tracking-tight text-foreground md:text-4xl lg:text-5xl text-balance">
          {h1}
        </h1>
        {subtitle && (
          <p className="mt-4 max-w-2xl text-lg leading-relaxed text-muted-foreground">{subtitle}</p>
        )}
      </div>
    </section>
  )
}
