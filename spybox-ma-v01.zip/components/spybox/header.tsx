"use client"

import Link from "next/link"
import { useState } from "react"
import { ChevronDown, Menu, X } from "lucide-react"

const SPYBOX_LINK = "https://spybox.io/?via=sign-ma"

const navigation = [
  {
    label: "Plateforme",
    children: [
      { label: "Qu'est-ce que Spybox ?", href: "/quest-ce-que-spybox" },
      { label: "Fonctionnement & Cr\u00e9dits SBC", href: "/fonctionnement-spybox" },
      { label: "Interface & Dashboard", href: "/interface-dashboard-spybox" },
      { label: "Pour qui est Spybox ?", href: "/pour-qui-spybox" },
      { label: "Cr\u00e9dits SBC expliqu\u00e9s", href: "/credits-sbc-spybox" },
      { label: "\u00c9volution 2024-2026", href: "/evolution-spybox-2026" },
    ],
  },
  {
    label: "Outils",
    children: [
      { label: "Minea (Product Research)", href: "/minea-spybox", accent: true },
      { label: "ShopHunter", href: "/shophunter-spybox" },
      { label: "AdSpy & PPAds", href: "/adspy-ppads-spybox", accent: true },
      { label: "Espionner les pubs", href: "/espionner-pubs-spybox" },
      { label: "TikTok Shop Spy", href: "/tiktok-shop-spybox" },
      { label: "Outils IA int\u00e9gr\u00e9s", href: "/spybox-ia-images", accent: true },
      { label: "RankerFox SEO", href: "/rankerfox-spybox", accent: true },
    ],
  },
  {
    label: "Comparaisons",
    children: [
      { label: "Spybox vs Semrush", href: "/spybox-vs-semrush" },
      { label: "Spybox vs Ahrefs", href: "/spybox-vs-ahrefs" },
      { label: "Spybox vs Minea seul", href: "/spybox-vs-minea-seul" },
      { label: "Spybox vs Group-Buy", href: "/spybox-vs-group-buy" },
      { label: "Meilleurs outils e-commerce", href: "/meilleurs-outils-ecommerce-2026" },
      { label: "Simulateur d'\u00e9conomies", href: "/simulateur-economies-spybox" },
    ],
  },
  {
    label: "Prix",
    href: "/prix-spybox",
  },
  {
    label: "Ressources",
    children: [
      { label: "Tutoriel d\u00e9butant", href: "/tutoriel-debutant-spybox" },
      { label: "Workflow Dropshipping", href: "/workflow-dropshipping-spybox" },
      { label: "Workflow SEO", href: "/workflow-seo-spybox" },
      { label: "FAQ compl\u00e8te", href: "/faq-spybox" },
      { label: "Support & Contact", href: "/support-spybox" },
    ],
  },
]

function DropdownMenu({ item }: { item: (typeof navigation)[number] }) {
  const [open, setOpen] = useState(false)

  if (!("children" in item) || !item.children) {
    return (
      <Link
        href={item.href!}
        className="text-sm font-medium text-muted-foreground transition-colors hover:text-foreground"
      >
        {item.label}
      </Link>
    )
  }

  return (
    <div
      className="relative"
      onMouseEnter={() => setOpen(true)}
      onMouseLeave={() => setOpen(false)}
    >
      <button
        type="button"
        className="flex items-center gap-1 text-sm font-medium text-muted-foreground transition-colors hover:text-foreground"
        aria-expanded={open}
        onClick={() => setOpen(!open)}
      >
        {item.label}
        <ChevronDown
          className={`h-3.5 w-3.5 transition-transform ${open ? "rotate-180" : ""}`}
          aria-hidden="true"
        />
      </button>

      {open && (
        <div className="absolute left-0 top-full z-50 pt-2">
          <div className="min-w-56 rounded-xl border border-border bg-card p-2 shadow-xl shadow-background/50">
            {item.children.map((child) => (
              <Link
                key={child.href}
                href={child.href}
                onClick={() => setOpen(false)}
                className={`flex rounded-lg px-3 py-2 text-sm transition-colors hover:bg-secondary ${
                  "accent" in child && child.accent
                    ? "font-medium text-primary hover:text-primary"
                    : "text-muted-foreground hover:text-foreground"
                }`}
              >
                {child.label}
              </Link>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}

export function Header() {
  const [mobileOpen, setMobileOpen] = useState(false)
  const [expandedMobile, setExpandedMobile] = useState<string | null>(null)

  return (
    <header className="sticky top-0 z-40 w-full border-b border-border/50 bg-background/80 backdrop-blur-xl">
      <div className="mx-auto flex h-14 max-w-7xl items-center justify-between px-4 lg:px-8">
        {/* Logo */}
        <div className="flex items-center gap-8">
          <Link href="/" className="flex items-center gap-2" aria-label="Spybox - Accueil">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                <path
                  d="M15.5 14h-.79l-.28-.27A6.471 6.471 0 0016 9.5 6.5 6.5 0 109.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"
                  fill="currentColor"
                  className="text-primary-foreground"
                />
              </svg>
            </div>
            <span className="text-lg font-bold tracking-tight text-foreground">Spybox</span>
          </Link>

          {/* Desktop nav */}
          <nav className="hidden items-center gap-5 lg:flex" aria-label="Navigation principale">
            {navigation.map((item) => (
              <DropdownMenu key={item.label} item={item} />
            ))}
          </nav>
        </div>

        {/* Right */}
        <div className="flex items-center gap-3">
          <a
            href={SPYBOX_LINK}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex h-9 items-center rounded-lg bg-primary px-4 text-sm font-semibold text-primary-foreground transition-colors hover:bg-accent"
          >
            Connexion
          </a>

          {/* Mobile toggle */}
          <button
            type="button"
            className="inline-flex h-9 w-9 items-center justify-center rounded-lg text-muted-foreground transition-colors hover:text-foreground lg:hidden"
            aria-label={mobileOpen ? "Fermer le menu" : "Ouvrir le menu"}
            onClick={() => setMobileOpen(!mobileOpen)}
          >
            {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </div>

      {/* Mobile menu */}
      {mobileOpen && (
        <nav
          className="border-t border-border bg-background px-4 pb-6 pt-4 lg:hidden"
          aria-label="Navigation mobile"
        >
          <div className="space-y-1">
            {navigation.map((item) => {
              if (!("children" in item) || !item.children) {
                return (
                  <Link
                    key={item.label}
                    href={item.href!}
                    onClick={() => setMobileOpen(false)}
                    className="flex rounded-lg px-3 py-2.5 text-sm font-medium text-foreground transition-colors hover:bg-secondary"
                  >
                    {item.label}
                  </Link>
                )
              }

              const isExpanded = expandedMobile === item.label

              return (
                <div key={item.label}>
                  <button
                    type="button"
                    onClick={() =>
                      setExpandedMobile(isExpanded ? null : item.label)
                    }
                    className="flex w-full items-center justify-between rounded-lg px-3 py-2.5 text-sm font-medium text-foreground transition-colors hover:bg-secondary"
                  >
                    {item.label}
                    <ChevronDown
                      className={`h-4 w-4 text-muted-foreground transition-transform ${
                        isExpanded ? "rotate-180" : ""
                      }`}
                      aria-hidden="true"
                    />
                  </button>
                  {isExpanded && (
                    <div className="ml-3 space-y-0.5 border-l border-border pl-3">
                      {item.children.map((child) => (
                        <Link
                          key={child.href}
                          href={child.href}
                          onClick={() => setMobileOpen(false)}
                          className="flex rounded-lg px-3 py-2 text-sm text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
                        >
                          {child.label}
                        </Link>
                      ))}
                    </div>
                  )}
                </div>
              )
            })}
          </div>
        </nav>
      )}
    </header>
  )
}
