"use client"

import { useState } from "react"
import { ArrowRight } from "lucide-react"

const SPYBOX_LINK = "https://spybox.io/?via=sign-ma"

const tools = [
  { name: "Semrush", price: 129.95 },
  { name: "Ahrefs", price: 99 },
  { name: "Minea", price: 97 },
  { name: "AdSpy", price: 149 },
  { name: "ChatGPT Plus", price: 20 },
  { name: "Midjourney", price: 30 },
  { name: "Mangools", price: 49 },
  { name: "ShopHunter", price: 47 },
  { name: "BigSpy", price: 99 },
  { name: "PPAds", price: 89 },
  { name: "ElevenLabs", price: 22 },
  { name: "Runway", price: 35 },
  { name: "HeyGen", price: 48 },
  { name: "Claude Pro", price: 20 },
]

export function SimulateurWidget() {
  const [selected, setSelected] = useState<Set<string>>(new Set())

  function toggle(name: string) {
    setSelected((prev) => {
      const next = new Set(prev)
      if (next.has(name)) next.delete(name)
      else next.add(name)
      return next
    })
  }

  const totalMonthly = tools.filter((t) => selected.has(t.name)).reduce((s, t) => s + t.price, 0)
  const totalAnnual = totalMonthly * 12
  const spyboxMensuelAnnual = 34.99 * 12
  const spyboxAnnuel = 249.99
  const savingsMensuel = totalAnnual - spyboxMensuelAnnual
  const savingsAnnuel = totalAnnual - spyboxAnnuel

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-xl font-bold text-foreground mb-4">Sélectionnez vos outils actuels</h2>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
          {tools.map((t) => (
            <button
              key={t.name}
              type="button"
              onClick={() => toggle(t.name)}
              className={`rounded-xl border px-4 py-3 text-left text-sm transition-all ${
                selected.has(t.name)
                  ? "border-primary bg-primary/10 text-foreground"
                  : "border-border bg-card text-muted-foreground hover:border-primary/30"
              }`}
            >
              <span className="block font-medium">{t.name}</span>
              <span className="block text-xs mt-1">{t.price.toFixed(2)} €/mois</span>
            </button>
          ))}
        </div>
      </div>

      <div className="rounded-xl border border-primary/30 bg-primary/5 p-6">
        <div className="grid gap-6 sm:grid-cols-4 text-center">
          <div>
            <p className="text-sm text-muted-foreground">Coût actuel / an</p>
            <p className="text-2xl font-bold text-foreground mt-1">
              {totalAnnual > 0 ? `${totalAnnual.toLocaleString("fr-FR", { minimumFractionDigits: 2 })} €` : "0 €"}
            </p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Spybox mensuel / an</p>
            <p className="text-2xl font-bold text-foreground mt-1">{spyboxMensuelAnnual.toFixed(2)} €</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Spybox annuel / an</p>
            <p className="text-2xl font-bold text-primary mt-1">{spyboxAnnuel.toFixed(2)} €</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Meilleure économie</p>
            <p className={`text-2xl font-bold mt-1 ${savingsAnnuel > 0 ? "text-primary" : "text-muted-foreground"}`}>
              {savingsAnnuel > 0 ? `${savingsAnnuel.toLocaleString("fr-FR", { minimumFractionDigits: 2 })} €` : "0 €"}
            </p>
          </div>
        </div>

        {savingsAnnuel > 0 && (
          <div className="mt-6 text-center">
            <p className="text-sm text-muted-foreground mb-4">
              Vous économisez{" "}
              <strong className="text-primary">{Math.round((savingsAnnuel / totalAnnual) * 100)} %</strong>
              {" avec l'abonnement annuel Spybox (20,83 €/mois) et le code "}
              <code className="rounded bg-primary/15 px-1.5 py-0.5 text-xs font-bold text-primary">GET25</code>
            </p>
            <a
              href={SPYBOX_LINK}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex h-12 items-center gap-2 rounded-xl bg-primary px-8 font-bold text-primary-foreground transition-all hover:bg-accent hover:shadow-lg hover:shadow-primary/25"
            >
              Passer à Spybox maintenant
              <ArrowRight className="h-4 w-4" aria-hidden="true" />
            </a>
          </div>
        )}
      </div>
    </div>
  )
}
