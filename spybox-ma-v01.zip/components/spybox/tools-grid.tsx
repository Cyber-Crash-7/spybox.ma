"use client"

import { useState } from "react"

interface Tool {
  name: string
  logo: string
  category: "Product Research" | "Ad Spy" | "SEO & Analytics" | "IA & Création" | "Vidéo & Audio" | "Design & Créatifs"
}

const tools: Tool[] = [
  // Product Research
  { name: "Minea", logo: "https://spybox-public.s3.eu-west-3.amazonaws.com/frontend/logo_images/4c72acb0-c77b-4be7-b172-5fbb409c28cc.png", category: "Product Research" },
  { name: "WinningHunter", logo: "https://spybox-public.s3.eu-west-3.amazonaws.com/frontend/logo_images/bcc32882-ace6-403a-868d-51b83516498b.png", category: "Product Research" },
  { name: "ShopHunter", logo: "https://spybox-public.s3.eu-west-3.amazonaws.com/frontend/logo_images/26dd1bd9-b263-4d97-a796-058c23eb6b07.png", category: "Product Research" },
  { name: "Sell The Trend", logo: "https://spybox-public.s3.eu-west-3.amazonaws.com/frontend/logo_images/4334adfb-5a25-46c5-b1dd-988e51aac618.png", category: "Product Research" },
  { name: "Niche Scrapper", logo: "https://spybox-public.s3.eu-west-3.amazonaws.com/frontend/logo_images/56c22b7a-514d-43cd-8982-c26faccef4e9.png", category: "Product Research" },
  { name: "Peeksta", logo: "https://spybox-public.s3.eu-west-3.amazonaws.com/frontend/logo_images/2219be72-223f-4a50-a7a6-fcb32d2365bd.png", category: "Product Research" },
  { name: "Dropship.io", logo: "https://spybox-public.s3.eu-west-3.amazonaws.com/frontend/logo_images/e4ebda9d-fda5-4d33-98a4-5b8a24160c95.png", category: "Product Research" },
  { name: "PPSPY", logo: "https://spybox-public.s3.eu-west-3.amazonaws.com/frontend/logo_images/d7123b1a-a424-4594-bd24-c81122feb5d2.png", category: "Product Research" },
  { name: "Kalodata", logo: "https://spybox-public.s3.eu-west-3.amazonaws.com/frontend/logo_images/bac1e4f6-51af-4c7f-9fe4-eabb8bbc8571.png", category: "Product Research" },
  { name: "Helium10", logo: "https://spybox-public.s3.eu-west-3.amazonaws.com/frontend/logo_images/c72d6961-00ae-4607-9a36-f53d4b213d1b.png", category: "Product Research" },

  // Ad Spy
  { name: "Adspy", logo: "https://spybox-public.s3.eu-west-3.amazonaws.com/frontend/logo_images/e32628b3-76dc-45ec-87b9-3e3e2b8fac54.png", category: "Ad Spy" },
  { name: "Adsparo", logo: "https://spybox-public.s3.eu-west-3.amazonaws.com/frontend/logo_images/0e24fcbf-696e-4591-bfdf-6ebd9db30e04.png", category: "Ad Spy" },
  { name: "Dropispy", logo: "https://spybox-public.s3.eu-west-3.amazonaws.com/frontend/logo_images/3648251d-744b-4688-a765-bb530373e889.png", category: "Ad Spy" },
  { name: "PipiAds", logo: "https://spybox-public.s3.eu-west-3.amazonaws.com/frontend/logo_images/dd8b2046-0c82-40af-b624-31f6c304edf0.png", category: "Ad Spy" },
  { name: "Foreplay", logo: "https://spybox-public.s3.eu-west-3.amazonaws.com/frontend/logo_images/dd0edce0-cb66-4590-b22f-5d7057983a03.png", category: "Ad Spy" },
  { name: "Atria", logo: "https://spybox-public.s3.eu-west-3.amazonaws.com/frontend/logo_images/75657a56-8708-4cbf-aab8-bf9977f5022d.png", category: "Ad Spy" },
  { name: "Gethookd", logo: "https://spybox-public.s3.eu-west-3.amazonaws.com/frontend/logo_images/a4c10b86-9d45-4f11-9c79-018fa313b1ad.png", category: "Ad Spy" },
  { name: "FutureLib", logo: "https://spybox-public.s3.eu-west-3.amazonaws.com/frontend/logo_images/8d68d9eb-28f6-4fb6-ad28-b4613da41a6a.png", category: "Ad Spy" },

  // SEO & Analytics
  { name: "Rankerfox", logo: "https://spybox-public.s3.eu-west-3.amazonaws.com/frontend/logo_images/7fc5ce6f-286e-4049-967a-6cbe36cb4137.png", category: "SEO & Analytics" },

  // IA & Création
  { name: "ChatGPT", logo: "https://spybox-public.s3.eu-west-3.amazonaws.com/frontend/logo_images/f1f67628-b389-4558-ae5c-14f65d0299e7.png", category: "IA & Création" },
  { name: "Claude AI", logo: "https://spybox-public.s3.eu-west-3.amazonaws.com/frontend/logo_images/6381a2c7-1d36-43a1-8bd3-c91cab47af53.jpg", category: "IA & Création" },
  { name: "Grok", logo: "https://spybox-public.s3.eu-west-3.amazonaws.com/frontend/logo_images/5cb9b742-56b8-4d55-a1ca-c30cb8c2dd0e.png", category: "IA & Création" },
  { name: "Perplexity AI", logo: "https://spybox-public.s3.eu-west-3.amazonaws.com/frontend/logo_images/782e9134-3c4a-470a-be9b-fa9c03444527.jpg", category: "IA & Création" },
  { name: "Kie AI", logo: "https://spybox-public.s3.eu-west-3.amazonaws.com/frontend/logo_images/98451ab7-f8f5-41de-9190-e7b48cca819b.png", category: "IA & Création" },
  { name: "Midjourney", logo: "https://spybox-public.s3.eu-west-3.amazonaws.com/frontend/logo_images/5a5b6902-7157-4c14-9c27-5ce4f5da028c.jpg", category: "IA & Création" },
  { name: "Flux AI", logo: "https://spybox-public.s3.eu-west-3.amazonaws.com/frontend/logo_images/89d272b0-0ae9-49f8-8a19-8670b7937158.jpg", category: "IA & Création" },
  { name: "Leonardo AI", logo: "https://spybox-public.s3.eu-west-3.amazonaws.com/frontend/logo_images/e41bfd79-7d7c-4d80-a180-f55f926fdca2.jpg", category: "IA & Création" },
  { name: "Krea AI", logo: "https://spybox-public.s3.eu-west-3.amazonaws.com/frontend/logo_images/9fa56635-dc27-48bd-98c0-50d02d89a9d5.jpg", category: "IA & Création" },
  { name: "Recraft", logo: "https://spybox-public.s3.eu-west-3.amazonaws.com/frontend/logo_images/edd55bcb-ef11-4f44-a0c8-0fc5514cec37.png", category: "IA & Création" },

  // Vidéo & Audio
  { name: "HeyGen", logo: "https://spybox-public.s3.eu-west-3.amazonaws.com/frontend/logo_images/ce086787-4b6f-418f-8a9c-157d72ccb0f3.jpg", category: "Vidéo & Audio" },
  { name: "Runway", logo: "https://spybox-public.s3.eu-west-3.amazonaws.com/frontend/logo_images/e043cc5f-c4eb-41a1-9d03-dc9b1898e9d0.jpg", category: "Vidéo & Audio" },
  { name: "Kling AI", logo: "https://spybox-public.s3.eu-west-3.amazonaws.com/frontend/logo_images/9d78204a-939a-4961-9773-3a51d5ae7c1e.jpg", category: "Vidéo & Audio" },
  { name: "Hailuo AI", logo: "https://spybox-public.s3.eu-west-3.amazonaws.com/frontend/logo_images/54d09c4c-d556-4deb-a439-5d14016b233e.jpg", category: "Vidéo & Audio" },
  { name: "Higgsfield", logo: "https://spybox-public.s3.eu-west-3.amazonaws.com/frontend/logo_images/2a38c0d8-9c97-4dcb-9a4c-08e4d36b1a3d.png", category: "Vidéo & Audio" },
  { name: "ElevenLabs", logo: "https://spybox-public.s3.eu-west-3.amazonaws.com/frontend/logo_images/5aa8e843-aa8f-4e92-99b8-4e49e88c8313.jpg", category: "Vidéo & Audio" },
  { name: "Submagic", logo: "https://spybox-public.s3.eu-west-3.amazonaws.com/frontend/logo_images/8205a623-9c3e-4265-b715-f127a2527cf8.jpg", category: "Vidéo & Audio" },
  { name: "Akool", logo: "https://spybox-public.s3.eu-west-3.amazonaws.com/frontend/logo_images/2ebef808-ee1c-459f-8273-9923397b40b5.png", category: "Vidéo & Audio" },
  { name: "Hoox", logo: "https://spybox-public.s3.eu-west-3.amazonaws.com/frontend/logo_images/73f6bab2-78da-472f-a1b1-c2f66e50559b.png", category: "Vidéo & Audio" },

  // Design & Créatifs
  { name: "Canva", logo: "https://spybox-public.s3.eu-west-3.amazonaws.com/frontend/logo_images/0699ac5b-5815-46ee-bdfa-9b829c10e9be.png", category: "Design & Créatifs" },
  { name: "Creatify", logo: "https://spybox-public.s3.eu-west-3.amazonaws.com/frontend/logo_images/e692a4ed-5eea-49ca-b406-a0cb6da0d9c5.png", category: "Design & Créatifs" },
  { name: "CreativeOS", logo: "https://spybox-public.s3.eu-west-3.amazonaws.com/frontend/logo_images/f972600a-b301-433b-83ac-4cfc0b795512.png", category: "Design & Créatifs" },
  { name: "Vmake", logo: "https://spybox-public.s3.eu-west-3.amazonaws.com/frontend/logo_images/4fec18e1-7b92-4a30-b4a1-e157ffeddcd3.png", category: "Design & Créatifs" },
]

const categories = [
  "Product Research",
  "Ad Spy",
  "SEO & Analytics",
  "IA & Création",
  "Vidéo & Audio",
  "Design & Créatifs",
] as const

const categoryLabels: Record<string, { color: string; description: string }> = {
  "Product Research": { color: "bg-primary/15 text-primary", description: "Trouvez les produits gagnants" },
  "Ad Spy": { color: "bg-emerald-400/15 text-emerald-400", description: "Espionnez les publicités concurrentes" },
  "SEO & Analytics": { color: "bg-sky-400/15 text-sky-400", description: "Dominez le référencement naturel" },
  "IA & Création": { color: "bg-amber-400/15 text-amber-400", description: "Générez du contenu avec l'IA" },
  "Vidéo & Audio": { color: "bg-rose-400/15 text-rose-400", description: "Créez des vidéos et de l'audio pro" },
  "Design & Créatifs": { color: "bg-fuchsia-400/15 text-fuchsia-400", description: "Concevez des visuels percutants" },
}

function ToolCard({ tool }: { tool: Tool }) {
  const [imgError, setImgError] = useState(false)
  const initials = tool.name.slice(0, 2).toUpperCase()

  return (
    <div className="flex items-center gap-3 rounded-xl border border-border bg-card p-3 transition-colors hover:border-primary/40 hover:bg-secondary">
      <div className="relative flex h-10 w-10 shrink-0 items-center justify-center overflow-hidden rounded-lg bg-secondary">
        {!imgError ? (
          <img
            src={tool.logo}
            alt={tool.name}
            width={40}
            height={40}
            loading="lazy"
            className="h-10 w-10 rounded-lg object-contain"
            onError={() => setImgError(true)}
          />
        ) : (
          <span className="flex h-10 w-10 items-center justify-center text-xs font-bold text-muted-foreground" aria-hidden="true">
            {initials}
          </span>
        )}
      </div>
      <span className="truncate text-sm font-medium text-foreground">{tool.name}</span>
    </div>
  )
}

export function ToolsGrid() {
  return (
    <section className="border-t border-border py-20 lg:py-28" id="outils">
      <div className="mx-auto max-w-7xl px-4 lg:px-8">
        <div className="mx-auto mb-14 max-w-2xl text-center">
          <h2 className="text-balance text-3xl font-bold tracking-tight text-foreground md:text-4xl">
            {"42 outils officiels, et plus de 90 au total"}
          </h2>
          <p className="mt-4 text-lg leading-relaxed text-muted-foreground">
            {"E-commerce, SEO, publicité, intelligence artificielle, vidéo, design : tous les outils leaders du marché accessibles en un clic via votre espace Spybox."}
          </p>
        </div>

        {categories.map((cat) => {
          const catTools = tools.filter((t) => t.category === cat)
          const meta = categoryLabels[cat]
          return (
            <div key={cat} className="mb-10">
              <div className="mb-4 flex items-center gap-3">
                <span className={`inline-flex rounded-md px-3 py-1 text-xs font-semibold ${meta.color}`}>
                  {cat}
                </span>
                <span className="hidden text-xs text-muted-foreground sm:inline">
                  {meta.description}
                </span>
                <div className="h-px flex-1 bg-border" />
                <span className="text-xs text-muted-foreground">
                  {catTools.length} {"outil"}{catTools.length > 1 ? "s" : ""}
                </span>
              </div>
              <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6">
                {catTools.map((tool) => (
                  <ToolCard key={tool.name} tool={tool} />
                ))}
              </div>
            </div>
          )
        })}

        <p className="mt-8 text-center text-sm text-muted-foreground">
          {"Et plus de 50 autres outils inclus dans votre abonnement Spybox — mise à jour mensuelle."}
        </p>
      </div>
    </section>
  )
}
